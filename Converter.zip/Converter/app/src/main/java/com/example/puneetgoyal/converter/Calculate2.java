package com.example.puneetgoyal.converter;

import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import java.math.BigDecimal;
import android.content.Intent;
import android.text.Html;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class Calculate2 extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    EditText t;
    Button b1,bpe,bx2,bx3,b10x,b2x,bsr,bcr,blog2,bsini,bcosi,btani,bsinhi,bcoshi,btanhi;
    static int chk=0,op=0,chk1=0,chk2=0,chk3=0,abc=0,count=0,c1=50,c2=100,c3=150,c4=200;
    static float result=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_calculate2);
        setTitle("");
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.colorCalDark));
        }
        t=(EditText) findViewById(R.id.editText1);
        b1=(Button) findViewById(R.id.b1);
        bpe=(Button) findViewById(R.id.bper);
        bx2=(Button) findViewById(R.id.bx2);
        bx3=(Button) findViewById(R.id.bx3);
        b10x=(Button) findViewById(R.id.b10x);
        b2x=(Button) findViewById(R.id.b2x);
        bsr=(Button) findViewById(R.id.bsr);
        bcr=(Button) findViewById(R.id.bcr);
        blog2=(Button) findViewById(R.id.blog2);
        bsini=(Button) findViewById(R.id.bsini);
        bcosi=(Button) findViewById(R.id.bcosi);
        btani=(Button) findViewById(R.id.btani);
        bsinhi=(Button) findViewById(R.id.bsinhi);
        bcoshi=(Button) findViewById(R.id.bcoshi);
        btanhi=(Button) findViewById(R.id.btanhi);
        View v = null;
        int con = getResources().getConfiguration().orientation;
        if (con==2)
        {
            capt(v);
        }
        String sk=getIntent().getStringExtra("value");
        t.setText(""+sk);

//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }
    public void capt(View v)
    {
        bx2.setText(Html.fromHtml("x<sup><small>2</small></sup>"));
        bx3.setText(Html.fromHtml("x<sup><small>3</small></sup>"));
        b10x.setText(Html.fromHtml("10<sup><small>x</small></sup>"));
        b2x.setText(Html.fromHtml("2<sup><small>x</small></sup>"));
        bsr.setText(Html.fromHtml("x<sup><small>1/2</small></sup>"));
        bcr.setText(Html.fromHtml("x<sup><small>1/3</small></sup>"));
        blog2.setText(Html.fromHtml("log<sub><small>2</small></sub>"));
        bsini.setText(Html.fromHtml("sin<sup><small>-1</small></sup>"));
        bcosi.setText(Html.fromHtml("cos<sup><small>-1</small></sup>"));
        btani.setText(Html.fromHtml("tan<sup><small>-1</small></sup>"));
        bsinhi.setText(Html.fromHtml("sinh<sup><small>-1</small></sup>"));
        bcoshi.setText(Html.fromHtml("cosh<sup><small>-1</small></sup>"));
        btanhi.setText(Html.fromHtml("tanh<sup><small>-1</small></sup>"));
    }

    public void perr(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            float k = (float) Float.parseFloat(a)/100;
            String g=String.valueOf(k);
            t.setText(""+g);
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void one(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"1");
                }
                else
                    t.setText("1");

                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000")||a.equals(""))
                {
                    t.setText(t.getText()+"1");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"1");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void two(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"2");
                }
                else
                    t.setText("2");
                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"2");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"2");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void three(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"3");
                }
                else
                    t.setText("3");
                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"3");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"3");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void four(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1||xyy==1)
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"4");
                }
                else
                    t.setText("4");

                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
                xyy=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"4");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"4");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void five(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1||xyy==1)
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"5");
                }
                else
                    t.setText("5");

                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
                xyy=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"5");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"5");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void six(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {		String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"6");
                }
                else
                    t.setText("6");

                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"6");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"6");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void seven(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);
        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"7");
                }
                else
                    t.setText("7");

                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"7");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"7");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void eight(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"8");
                }
                else
                    t.setText("8");

                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"8");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"8");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void nine(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {		String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"9");
                }
                else
                    t.setText("9");

                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"9");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"9");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void zero(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"0");
                }
                else
                    t.setText("0");

                chk=0;
                chk1=0;
                chk2=0;
                chk3=0;
                count++;
                abc=0;
            }
            else
            {
                String a = t.getText().toString();
                if(a.equals("0.")||a.equals("0.0")||a.equals("")||a.equals("0.00")||a.equals("0.000")||a.equals("0.0000")||a.equals("0.00000")||a.equals("0.000000")||a.equals("0.00000000")||a.equals("0.000000000")||a.equals("0.0000000000"))
                {
                    t.setText(t.getText()+"0");
                }
                else
                {
                    float b = (Float.parseFloat(a));
                    if(b==0.0)
                    {
                        t.setText("");
                    }
                    t.setText(t.getText()+"0");
                }
                count++;
                abc=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }

    public void subtractt(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {

            if(chk3==0)
            {
                chk1=1;
                chk=1;
                chk2=1;
                if(abc==0)
                    equall(v);

                String a = t.getText().toString();
                Float i=Float.parseFloat(a);
                if(result==0)
                {
                    result = i;
                }
                else
                {
                    result = result - i;
                }
                String chk=String.valueOf(result);
                char s[]=new char[chk.length()];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }    	chk3=1;
                op=4;
                abc=1;
            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void multiplyy(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk1==0)
            {
                chk=1;
                chk3=1;
                chk2=1;

                equall(v);

                String a = t.getText().toString();
                float i=Float.parseFloat(a);
                if(result!=0.0)
                {
                    result = result * i;
                }
                else
                {
                    result=1;
                    result = result * i;
                }
                String chk=String.valueOf(result);
                char s[]=new char[chk.length()];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }




                chk1=1;
                op=2;
                abc=1;
            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void dividee(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk2==0)
            {
                chk1=1;
                chk=1;
                chk3=1;

                equall(v);

                String a = t.getText().toString();
                Float i=Float.parseFloat(a);
                if(result==0)
                {
                    result = i;
                }
                else
                {
                    result = result / i;
                }
                String chk=String.valueOf(result);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }    	chk2=1;
                op=3;
            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void addd(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==0)
            {
                chk1=1;
                chk2=1;
                chk3=1;
                if(abc==0)
                    equall(v);

                String a = t.getText().toString();
                Float i=Float.parseFloat(a);
                result = result + i;

                String chkq=String.valueOf(result);
                char s[]=new char[chkq.length()+1];
                s=chkq.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }
                chk=1;
                op=1;
                abc=1;
            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void equall(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {

            if(op==1)
            {
                String a = t.getText().toString();

                result = result+ Float.parseFloat(a);
                String chk=String.valueOf(result);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }  	result=0;
                op=0;
            }
            else if(op==2)
            {
                String a = t.getText().toString();

                result = result * Float.parseFloat(a);
                String chk=String.valueOf(result);
                char s[]=new char[chk.length()];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }   	op=0;
                result=0;
            }
            else if(op==3)
            {
                String a = t.getText().toString();

                result = result / Float.parseFloat(a);
                String chk=String.valueOf(result);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }   	op=0;
                result=0;

            }
            else if(op==4)
            {
                String a = t.getText().toString();

                result = result - Float.parseFloat(a);
                String chk=String.valueOf(result);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }  	op=0;
                result=0;
            }
            else if(op==5)
            {
                String a = t.getText().toString();
                float second = Float.parseFloat(a);
                result=(float) Math.pow(first, second);
                String chk=String.valueOf(result);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)result;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+result);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }
                op=0;
                result=0;

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void dott(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            if(chk==1||chk1==1||chk2==1||chk3==1)
            {
                t.setText("0.");
            }
            else
            {
                String a = t.getText().toString();
                int l = a.length();

                char [] s = new char[l+1];
                s= a.toCharArray();
                int e=1;
                for(int w=0;w<s.length;w++)
                {
                    if(s[w] == '.')
                    {
                        e=0;
                        break;
                    }

                }
                if(e==1)
                    t.setText(t.getText() + ".");
            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }





    }

    public void clearr(View v)
    {
        t.setText("0");
        chk=0;
        chk1=0;
        chk2=0;
        chk3=0;
        op=0;
        result=0;
        count=0;
        c1=50;
        c2=100;
        c3=150;
        c4=200;

    }
    public void deletee(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            if(a.length()==1)
            {
                t.setText("0");
            }
            else
            {
                a = a.substring(0,a.length()-1);
                t.setText(""+a);
            }

        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }

    public void x2(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double fa= Double.parseDouble(a);
            if(fa<(99999999999999f)&&fa>(-999999999999f))
            {
                fa=  (Double)fa*fa;

                String chk= String.valueOf(fa);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }


                String f=String.valueOf(s);
                int p = Integer.parseInt(f.substring(0,w));
                int ap= Integer.parseInt(f.substring(w+1, f.length()));
                if(ap>0)
                {
                    t.setText(""+fa);

                }
                else
                {
                    t.setText(""+p);

                }
            }
            else
                t.setText("Error");


        }
        catch(Exception e)
        {
            t.setText("Error");
        }


    }
    public void x3(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double fa= Double.parseDouble(a);
            if(fa<(999999999f)&&fa>(-999999999f))
            {
                fa=  (Double)fa*fa*fa;

                String chk= String.valueOf(fa);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }


                String f=String.valueOf(s);
                int p = Integer.parseInt(f.substring(0,w));
                int ap= Integer.parseInt(f.substring(w+1, f.length()));
                if(ap>0)
                {
                    t.setText(""+fa);

                }
                else
                {
                    t.setText(""+p);

                }
            }
            else
                t.setText("Error");

        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    static int xyy=0,xyyy=0;
    static float first=0;
    public void b10x(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double d= Double.parseDouble(a);
            Double h=(double) 10;
            Double fa= Math.pow(h, d);


            String chk= String.valueOf(fa);
            char s[]=new char[chk.length()+1];
            s=chk.toCharArray();
            int w=0;
            for(w=0;w<s.length;w++)
            {
                if(s[w]=='.')
                {
                    break;
                }
            }


            String f=String.valueOf(s);
            int p = Integer.parseInt(f.substring(0,w));
            int ap= Integer.parseInt(f.substring(w+1, f.length()));
            if(ap>0)
            {
                t.setText(""+fa);

            }
            else
            {
                t.setText(""+p);

            }

        }
        catch(Exception e)
        {
            t.setText("Error");
        }


    }
    public void b2x(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double d= Double.parseDouble(a);
            Double h=(double) 2;
            Double fa= Math.pow(h, d);

            String chk= String.valueOf(fa);
            char s[]=new char[chk.length()+1];
            s=chk.toCharArray();
            int w=0;
            for(w=0;w<s.length;w++)
            {
                if(s[w]=='.')
                {
                    break;
                }
            }


            String f=String.valueOf(s);
            int p = Integer.parseInt(f.substring(0,w));
            int ap= Integer.parseInt(f.substring(w+1, f.length()));
            if(ap>0)
            {
                t.setText(""+BigDecimal.valueOf(fa).toPlainString());

            }
            else
            {
                t.setText(""+BigDecimal.valueOf(p).toPlainString());

            }

        }
        catch(Exception e)
        {
            t.setText("Error");
        }



    }
    public void sr(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double d=Double.parseDouble(a);
            float fa =  (float)Math.sqrt(d);
            //String chk=BigDecimal.valueOf(fa).toPlainString();

            String chk= String.valueOf(fa);
            char s[]=new char[chk.length()+1];
            s=chk.toCharArray();
            int w=0;
            for(w=0;w<s.length;w++)
            {
                if(s[w]=='.')
                {
                    break;
                }
            }
            if(w==s.length+1)
            {
                int b=(int)fa;
                t.setText(""+b);
            }
            else
            {
                String f=String.valueOf(s);
                int p = Integer.parseInt(f.substring(0,w));
                int ap= Integer.parseInt(f.substring(w+1, f.length()));
                if(ap>0)
                {
                    t.setText(""+BigDecimal.valueOf(fa).toPlainString());

                }
                else
                {
                    t.setText(""+BigDecimal.valueOf(p).toPlainString());

                }

            }


        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void cr(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double d=Double.parseDouble(a);
            float fa =  (float)Math.cbrt(d);
            //String chk=BigDecimal.valueOf(fa).toPlainString();

            String chk= String.valueOf(fa);
            char s[]=new char[chk.length()+1];
            s=chk.toCharArray();
            int w=0;
            for(w=0;w<s.length;w++)
            {
                if(s[w]=='.')
                {
                    break;
                }
            }
            if(w==s.length+1)
            {
                int b=(int)fa;
                t.setText(""+b);
            }
            else
            {
                String f=String.valueOf(s);
                int p = Integer.parseInt(f.substring(0,w));
                int ap= Integer.parseInt(f.substring(w+1, f.length()));
                if(ap>0)
                {
                    t.setText(""+fa);

                }
                else
                {
                    t.setText(""+p);

                }

            }

        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void log2(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double d=Double.parseDouble(a);

            d= Math.log(d)/Math.log(2);
            if(d>0)
            {
                Double fa =  d;
                //String chk=BigDecimal.valueOf(fa).toPlainString();

                String chk= String.valueOf(fa);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }


                String f=String.valueOf(s);
                int p = Integer.parseInt(f.substring(0,w));
                int ap= Integer.parseInt(f.substring(w+1, f.length()));
                if(ap>0)
                {
                    t.setText(""+fa);

                }
                else
                {
                    t.setText(""+p);

                }

            }

        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void lnn(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {

            String a = t.getText().toString();
            Double d=Double.parseDouble(a);
            if(d>0)
            {
                float fa =  (float)Math.log(d);
                //String chk=BigDecimal.valueOf(fa).toPlainString();

                String chk= String.valueOf(fa);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.')
                    {
                        break;
                    }
                }
                if(w==s.length+1)
                {
                    int b=(int)fa;
                    t.setText(""+b);
                }
                else
                {
                    String f=String.valueOf(s);
                    int p = Integer.parseInt(f.substring(0,w));
                    int ap= Integer.parseInt(f.substring(w+1, f.length()));
                    if(ap>0)
                    {
                        t.setText(""+fa);

                    }
                    else
                    {
                        t.setText(""+p);

                    }

                }
            }
            else
                t.setText("Error");

        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void bsini(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            float k =  Float.parseFloat(a);

            if(k>=-1.0&&k<=1.0)
            {
                float h = (float) Math.asin((double)k);
                t.setText(""+h);
            }
            else
            {
                t.setText("Error");
            }

        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void bcosi(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            float k =  Float.parseFloat(a);
            if(k>=-1&&k<=1)
            {
                float h = (float) Math.acos((double)k);
                t.setText(""+h);
            }
            else
            {
                t.setText("Error");
            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void btani(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            float k =  Float.parseFloat(a);
            float h = (float) Math.atan((double)k);
            t.setText(""+h);

        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void e(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);
        t.setText("2.71828182");
    }
    public void pi(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);
        t.setText("3.14159265");
    }

    public void bsinhi(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double d=Double.parseDouble(a);
            d = Math.log(d + Math.sqrt(d*d + 1.0));
            t.setText(""+d);
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void bcoshi(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double x=Double.parseDouble(a);
            if(x>=1){
                x=  Math.log(x + Math.sqrt(x*x - 1.0));
                t.setText(""+x);
            }
            else
            {
                t.setText("Error");
            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }
    }
    public void btanhi(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double x=Double.parseDouble(a);
            if(x<1&&x>-1)
            {
                x= 0.5*Math.log( (x + 1.0) / (x - 1.0) );
                t.setText(""+x);
            }
            else
            {
                t.setText("Error");
            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }


    }

    public void bfact(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            Double fa=Double.parseDouble(a);
            if(fa==0)
                t.setText("1");
            if(fa<50&&fa>0){
                String chk= String.valueOf(fa);
                char s[]=new char[chk.length()+1];
                s=chk.toCharArray();
                int w=0;
                for(w=0;w<s.length;w++)
                {
                    if(s[w]=='.'){
                        break;
                    }
                }
                String f=String.valueOf(s);
                int p = Integer.parseInt(f.substring(0,w));
                int ap= Integer.parseInt(f.substring(w+1, f.length()));
                if(ap>0)
                {
                    double fact=1;
                    double i;
                    for(i=fa;i>1;i=i-1)
                    {
                        fact=fact*i;
                    }
                    if(i>0&&i<0.1)
                        fact=1;
                    if(i>=0.1&&i<0.2)
                        fact=fact*0.951350769866873;
                    if(i>=0.2&&i<0.3)
                        fact=fact*0.918168742399761;
                    if(i>=0.3&&i<0.4)
                        fact=fact*0.897470696306277;
                    if(i>=0.4&&i<0.5)
                        fact=fact*0.887263817503075;
                    if(i>=0.5&&i<0.6)
                        fact=fact*0.886226925452758;
                    if(i>=0.6&&i<0.7)
                        fact=fact*0.893515349287690;
                    if(i>=0.7&&i<0.8)
                        fact=fact*0.908638732853290;
                    if(i>=0.8&&i<0.9)
                        fact=fact*0.931383770980243;
                    if(i>=0.9&&i<1)
                        fact=fact*0.961765831907387;
                    t.setText(""+BigDecimal.valueOf(fact).toPlainString());
                }
                else
                {		long fact=1;
                    for(int i=2;i<=p;i++)
                    {
                        fact=fact*i;
                    }
                    t.setText(""+BigDecimal.valueOf(fact).toPlainString());
                }

            }
            else
                t.setText("Error");

        }
        catch(Exception e)
        {
            t.setText("Error");
        }

    }
    public void pm(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);

        try
        {
            String a = t.getText().toString();
            float fa= Float.parseFloat(a);
            fa = 0-fa;
            String chk= String.valueOf(fa);
            char s[]=new char[chk.length()+1];
            s=chk.toCharArray();
            int w=0;
            for(w=0;w<s.length;w++)
            {
                if(s[w]=='.')
                {
                    break;
                }
            }
            if(w==s.length+1)
            {
                int b=(int)fa;
                t.setText(""+b);
            }
            else
            {

                String f=String.valueOf(s);
                int p = Integer.parseInt(f.substring(0,w));
                int ap= Integer.parseInt(f.substring(w+1, f.length()));
                if(ap>0)
                {
                    t.setText(""+fa);

                }
                else
                {
                    t.setText(""+p);

                }

            }
        }
        catch(Exception e)
        {
            t.setText("Error");
        }



    }
    public void b2nd(View v)
    {
        String aw = t.getText().toString();
        if(aw.equals("Error"))
            clearr(v);
        Intent i=new Intent(Calculate2.this,Calculate.class);
        i.putExtra("valu", t.getText().toString());
        Calculate2.this.finish();
        startActivity(i);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.calculate2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.currency) {
            startActivity(new Intent(this,Currency.class));
            this.finish();
        } else if (id == R.id.area) {
            startActivity(new Intent(this,Area.class));
            this.finish();
        }
        else if (id == R.id.angle) {
            startActivity(new Intent(this, Angle.class));
            this.finish();
        }
        else if (id == R.id.storage) {
            startActivity(new Intent(this, Data_Storage.class));
            this.finish();
        }
        else if (id == R.id.astronomical) {
            startActivity(new Intent(this, Astronomical.class));
            this.finish();
        }
        else if (id == R.id.calulater) {
            startActivity(new Intent(this, Calculate.class));
            this.finish();
        }
        else if (id == R.id.capture) {
            Intent i=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            startActivity(i);
        }
        else if (id == R.id.gallary) {
            Intent i=new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            startActivity(i);
        }

        else if (id == R.id.flash) {
            startActivity(new Intent(this, Flash.class));
            this.finish();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
