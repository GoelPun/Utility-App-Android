package com.example.puneetgoyal.converter;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.content.pm.PackageManager;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.Toast;

public class Flash extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    Camera camera;
    Parameters params;
    ImageButton b;
    boolean hasFlash,on,off;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flash);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP)
        {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.colorCalDark));
        }
        b=(ImageButton) findViewById(R.id.button1);
        hasFlash = getApplicationContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);


        if (camera == null) {
            try {
                camera = Camera.open();
                params = camera.getParameters();



            } catch (RuntimeException e) {
            }

            off=true;
            b.setBackgroundResource(R.drawable.stop);


            b.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                    if(!hasFlash)
                    {
                        Toast.makeText(getApplicationContext(), "Your mobile doesn't support Flash", Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        if(off)
                        {
                            b.setBackgroundResource(R.drawable.star);
                            params = camera.getParameters();
                            params.setFlashMode(Parameters.FLASH_MODE_TORCH);
                            camera.setParameters(params);
                            camera.startPreview();
                            off=false;
                        }
                        else
                        {
                            b.setBackgroundResource(R.drawable.stop);
                            params = camera.getParameters();
                            params.setFlashMode(Parameters.FLASH_MODE_OFF);
                            camera.setParameters(params);
                            camera.stopPreview();
                            off=true;
                        }
                    }
                }
            });
        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.flash, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.currency) {
            startActivity(new Intent(this,Currency.class));
            this.finish();
        } else if (id == R.id.area) {
            startActivity(new Intent(this,Area.class));
            this.finish();
        }
        else if (id == R.id.angle) {
            startActivity(new Intent(this, Angle.class));
            this.finish();
        }
        else if (id == R.id.storage) {
            startActivity(new Intent(this, Data_Storage.class));
            this.finish();
        }
        else if (id == R.id.astronomical) {
            startActivity(new Intent(this, Astronomical.class));
            this.finish();
        }
        else if (id == R.id.capture) {
            Intent i=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            startActivity(i);
        }
        else if (id == R.id.gallary) {
            Intent i=new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            startActivity(i);
        }
        else if (id == R.id.calulater) {
            startActivity(new Intent(this, Calculate.class));
            this.finish();
        }

        else if (id == R.id.flash) {
            startActivity(new Intent(this, Flash.class));
            this.finish();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
