package com.example.puneetgoyal.converter;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import java.math.BigDecimal;

import android.provider.MediaStore;
import android.text.TextWatcher;
import android.text.Editable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

public class Currency extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    EditText india, us, euro, ausdollar, yan, pound, swiss, cdollar, sar;
    private CustomWatcher watcher1,watcher2,watcher3,watcher4,watcher5,watcher6,watcher7,watcher8,watcher9;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Currency");
        setContentView(R.layout.activity_currency);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP)
        {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.colorPrimaryDark));
        }
        india = (EditText) findViewById(R.id.editText1);
        us = (EditText) findViewById(R.id.editText2);
        euro = (EditText) findViewById(R.id.editText3);
        ausdollar = (EditText) findViewById(R.id.editText4);
        yan = (EditText) findViewById(R.id.editText5);
        pound = (EditText) findViewById(R.id.editText6);
        swiss = (EditText) findViewById(R.id.editText7);
        cdollar = (EditText) findViewById(R.id.editText8);
        sar = (EditText) findViewById(R.id.editText9);
        watcher1=new CustomWatcher(india);
        watcher2=new CustomWatcher(us);
        watcher3=new CustomWatcher(euro);
        watcher4=new CustomWatcher(ausdollar);
        watcher5=new CustomWatcher(yan);
        watcher6=new CustomWatcher(pound);
        watcher7=new CustomWatcher(swiss);
        watcher8=new CustomWatcher(cdollar);
        watcher9=new CustomWatcher(sar);



        india.addTextChangedListener(watcher1);
        us.addTextChangedListener(watcher2);
        euro.addTextChangedListener(watcher3);
        ausdollar.addTextChangedListener(watcher4);
        yan.addTextChangedListener(watcher5);
        pound.addTextChangedListener(watcher6);
        swiss.addTextChangedListener(watcher7);
        cdollar.addTextChangedListener(watcher8);
        sar.addTextChangedListener(watcher9);




        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setBackgroundTintList(getResources().getColorStateList(R.color.colorPrimary));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public	class CustomWatcher implements TextWatcher{
        private View view;
        public CustomWatcher(View view) {
            this.view = view;
        }

        @Override
        public void afterTextChanged(Editable arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                  int arg3) {

            switch(view.getId())
            {
                case R.id.editText1:
                    if(india.length()!=0)
                    {
                        us.removeTextChangedListener(watcher2);
                        String str1 = india.getText().toString();
                        double d1 = Double.parseDouble(str1) / 66.55;
                        str1 = BigDecimal.valueOf(d1).toString();
                        us.setText("" + str1);
                        us.addTextChangedListener(watcher2);
                        //us.setError("This field cant be blank");

                        euro.removeTextChangedListener(watcher3);
                        String str2 = india.getText().toString();
                        double d2 = Double.parseDouble(str2) / 71.39;
                        str2 = BigDecimal.valueOf(d2).toString();
                        euro.setText("" + str2);
                        euro.addTextChangedListener(watcher3);

                        ausdollar.removeTextChangedListener(watcher4);
                        String str3 = india.getText().toString();
                        double d3 = Double.parseDouble(str3) / 48.20;
                        str3 = BigDecimal.valueOf(d3).toString();
                        ausdollar.setText("" + str3);
                        ausdollar.addTextChangedListener(watcher4);

                        yan.removeTextChangedListener(watcher5);
                        String str4 = india.getText().toString();
                        double d4 = Double.parseDouble(str4) / 0.55;
                        str4 = BigDecimal.valueOf(d4).toString();
                        yan.setText("" + str4);
                        yan.addTextChangedListener(watcher5);

                        pound.removeTextChangedListener(watcher6);
                        String str5 = india.getText().toString();
                        double d5 = Double.parseDouble(str5) / 97.68;
                        str5 = BigDecimal.valueOf(d5).toString();
                        pound.setText("" + str5);
                        pound.addTextChangedListener(watcher6);

                        swiss.removeTextChangedListener(watcher7);
                        String str6 = india.getText().toString();
                        double d6 = Double.parseDouble(str6) / 66.14;
                        str6 = BigDecimal.valueOf(d6).toString();
                        swiss.setText("" + str6);
                        swiss.addTextChangedListener(watcher7);

                        cdollar.removeTextChangedListener(watcher8);
                        String str7 = india.getText().toString();
                        double d7 = Double.parseDouble(str7) / 47.82;
                        str7 = BigDecimal.valueOf(d7).toString();
                        cdollar.setText("" + str7);
                        cdollar.addTextChangedListener(watcher8);

                        sar.removeTextChangedListener(watcher9);
                        String str8 = india.getText().toString();
                        double d8 = Double.parseDouble(str8) / 4.28;
                        str8 = BigDecimal.valueOf(d8).toString();
                        sar.setText("" + str8);
                        sar.addTextChangedListener(watcher9);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
                case R.id.editText2:
                    if(us.length()!=0)
                    {
                        india.removeTextChangedListener(watcher1);
                        String str1 = us.getText().toString();
                        double d1 = Double.parseDouble(str1) * 66.55;
                        str1 = BigDecimal.valueOf(d1).toString();
                        india.setText("" + str1);
                        india.addTextChangedListener(watcher1);

                        euro.removeTextChangedListener(watcher3);
                        String str2 = us.getText().toString();
                        double d2 = Double.parseDouble(str2) * 0.93;
                        str2 = BigDecimal.valueOf(d2).toString();
                        euro.setText("" + str2);
                        euro.addTextChangedListener(watcher3);

                        ausdollar.removeTextChangedListener(watcher4);
                        String str3 = us.getText().toString();
                        double d3 = Double.parseDouble(str3) * 1.40;
                        str3 = BigDecimal.valueOf(d3).toString();
                        ausdollar.setText("" + str3);
                        ausdollar.addTextChangedListener(watcher4);

                        yan.removeTextChangedListener(watcher5);
                        String str4 = us.getText().toString();
                        double d4 = Double.parseDouble(str4) * 119.16;
                        str4 = BigDecimal.valueOf(d4).toString();
                        yan.setText("" + str4);
                        yan.addTextChangedListener(watcher5);

                        pound.removeTextChangedListener(watcher6);
                        String str5 = us.getText().toString();
                        double d5 = Double.parseDouble(str5) * .68;
                        str5 = BigDecimal.valueOf(d5).toString();
                        pound.setText("" + str5);
                        pound.addTextChangedListener(watcher6);

                        swiss.removeTextChangedListener(watcher7);
                        String str6 = us.getText().toString();
                        double d6 = Double.parseDouble(str6) * 1.01;
                        str6 = BigDecimal.valueOf(d6).toString();
                        swiss.setText("" + str6);
                        swiss.addTextChangedListener(watcher7);

                        cdollar.removeTextChangedListener(watcher8);
                        String str7 = us.getText().toString();
                        double d7 = Double.parseDouble(str7) * 1.40;
                        str7 = BigDecimal.valueOf(d7).toString();
                        cdollar.setText("" + str7);
                        cdollar.addTextChangedListener(watcher8);

                        sar.removeTextChangedListener(watcher9);
                        String str8 = us.getText().toString();
                        double d8 = Double.parseDouble(str8) * 15.61;
                        str8 = BigDecimal.valueOf(d8).toString();
                        sar.setText("" + str8);
                        sar.addTextChangedListener(watcher9);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
                case R.id.editText3:
                    if(euro.length()!=0)
                    {
                        india.removeTextChangedListener(watcher1);
                        String str1 = us.getText().toString();
                        double d1 = Double.parseDouble(str1) * 66.55;
                        str1 = BigDecimal.valueOf(d1).toString();
                        india.setText("" + str1);
                        india.addTextChangedListener(watcher1);

                        us.removeTextChangedListener(watcher2);
                        String str2 = euro.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.93;
                        str2 = BigDecimal.valueOf(d2).toString();
                        us.setText("" + str2);
                        us.addTextChangedListener(watcher2);

                        ausdollar.removeTextChangedListener(watcher4);
                        String str3 = euro.getText().toString();
                        double d3 = Double.parseDouble(str3) / .67;
                        str3 = BigDecimal.valueOf(d3).toString();
                        ausdollar.setText("" + str3);
                        ausdollar.addTextChangedListener(watcher4);

                        yan.removeTextChangedListener(watcher5);
                        String str4 = euro.getText().toString();
                        double d4 = Double.parseDouble(str4) / 0.0078;
                        str4 = BigDecimal.valueOf(d4).toString();
                        yan.setText("" + str4);
                        yan.addTextChangedListener(watcher5);

                        pound.removeTextChangedListener(watcher6);
                        String str5 = euro.getText().toString();
                        double d5 = Double.parseDouble(str5) / 1.37;
                        str5 = BigDecimal.valueOf(d5).toString();
                        pound.setText("" + str5);
                        pound.addTextChangedListener(watcher6);

                        swiss.removeTextChangedListener(watcher7);
                        String str6 = euro.getText().toString();
                        double d6 = Double.parseDouble(str6) / 0.92;
                        str6 = BigDecimal.valueOf(d6).toString();
                        swiss.setText("" + str6);
                        swiss.addTextChangedListener(watcher7);

                        cdollar.removeTextChangedListener(watcher8);
                        String str7 = euro.getText().toString();
                        double d7 = Double.parseDouble(str7) / 0.67;
                        str7 = BigDecimal.valueOf(d7).toString();
                        cdollar.setText("" + str7);
                        cdollar.addTextChangedListener(watcher8);

                        sar.removeTextChangedListener(watcher9);
                        String str8 = euro.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.060;
                        str8 = BigDecimal.valueOf(d8).toString();
                        sar.setText("" + str8);
                        sar.addTextChangedListener(watcher9);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
                case R.id.editText4:
                    if(ausdollar.length()!=0)
                    {
                        india.removeTextChangedListener(watcher1);
                        String str1 = ausdollar.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.021;
                        str1 = BigDecimal.valueOf(d1).toString();
                        india.setText("" + str1);
                        india.addTextChangedListener(watcher1);

                        us.removeTextChangedListener(watcher2);
                        String str2 = ausdollar.getText().toString();
                        double d2 = Double.parseDouble(str2) / 1.40;
                        str2 = BigDecimal.valueOf(d2).toString();
                        us.setText("" + str2);
                        us.addTextChangedListener(watcher2);

                        euro.removeTextChangedListener(watcher3);
                        String str3 = ausdollar.getText().toString();
                        double d3 = Double.parseDouble(str3) / 1.50;
                        str3 = BigDecimal.valueOf(d3).toString();
                        euro.setText("" + str3);
                        euro.addTextChangedListener(watcher3);

                        yan.removeTextChangedListener(watcher5);
                        String str4 = ausdollar.getText().toString();
                        double d4 = Double.parseDouble(str4) / 0.012;
                        str4 = BigDecimal.valueOf(d4).toString();
                        yan.setText("" + str4);
                        yan.addTextChangedListener(watcher5);

                        pound.removeTextChangedListener(watcher6);
                        String str5 = ausdollar.getText().toString();
                        double d5 = Double.parseDouble(str5) / 2.05;
                        str5 = BigDecimal.valueOf(d5).toString();
                        pound.setText("" + str5);
                        pound.addTextChangedListener(watcher6);

                        swiss.removeTextChangedListener(watcher7);
                        String str6 = ausdollar.getText().toString();
                        double d6 = Double.parseDouble(str6) / 1.38;
                        str6 = BigDecimal.valueOf(d6).toString();
                        swiss.setText("" + str6);
                        swiss.addTextChangedListener(watcher7);

                        cdollar.removeTextChangedListener(watcher8);
                        String str7 = ausdollar.getText().toString();
                        double d7 = Double.parseDouble(str7) / 1.00;
                        str7 = BigDecimal.valueOf(d7).toString();
                        cdollar.setText("" + str7);
                        cdollar.addTextChangedListener(watcher8);

                        sar.removeTextChangedListener(watcher9);
                        String str8 = ausdollar.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.090;
                        str8 = BigDecimal.valueOf(d8).toString();
                        sar.setText("" + str8);
                        sar.addTextChangedListener(watcher9);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
                case R.id.editText5:
                    if(yan.length()!=0)
                    {
                        india.removeTextChangedListener(watcher1);
                        String str1 = yan.getText().toString();
                        double d1 = Double.parseDouble(str1) / 1.79;
                        str1 = BigDecimal.valueOf(d1).toString();
                        india.setText("" + str1);
                        india.addTextChangedListener(watcher1);

                        us.removeTextChangedListener(watcher2);
                        String str2 = yan.getText().toString();
                        double d2 = Double.parseDouble(str2) / 119.05;
                        str2 = BigDecimal.valueOf(d2).toString();
                        us.setText("" + str2);
                        us.addTextChangedListener(watcher2);

                        euro.removeTextChangedListener(watcher3);
                        String str3 = yan.getText().toString();
                        double d3 = Double.parseDouble(str3) / 127.80;
                        str3 = BigDecimal.valueOf(d3).toString();
                        euro.setText("" + str3);
                        euro.addTextChangedListener(watcher3);

                        ausdollar.removeTextChangedListener(watcher4);
                        String str4 = yan.getText().toString();
                        double d4 = Double.parseDouble(str4) / 84.96;
                        str4 = BigDecimal.valueOf(d4).toString();
                        ausdollar.setText("" + str4);
                        ausdollar.addTextChangedListener(watcher4);

                        pound.removeTextChangedListener(watcher6);
                        String str5 = yan.getText().toString();
                        double d5 = Double.parseDouble(str5) / 174.45;
                        str5 = BigDecimal.valueOf(d5).toString();
                        pound.setText("" + str5);
                        pound.addTextChangedListener(watcher6);

                        swiss.removeTextChangedListener(watcher7);
                        String str6 = yan.getText().toString();
                        double d6 = Double.parseDouble(str6) / 117.79;
                        str6 = BigDecimal.valueOf(d6).toString();
                        swiss.setText("" + str6);
                        swiss.addTextChangedListener(watcher7);

                        cdollar.removeTextChangedListener(watcher8);
                        String str7 = yan.getText().toString();
                        double d7 = Double.parseDouble(str7) / 85.02;
                        str7 = BigDecimal.valueOf(d7).toString();
                        cdollar.setText("" + str7);
                        cdollar.addTextChangedListener(watcher8);

                        sar.removeTextChangedListener(watcher9);
                        String str8 = yan.getText().toString();
                        double d8 = Double.parseDouble(str8) / 7.63;
                        str8 = BigDecimal.valueOf(d8).toString();
                        sar.setText("" + str8);
                        sar.addTextChangedListener(watcher9);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
                case R.id.editText6:
                    if(pound.length()!=0)
                    {
                        india.removeTextChangedListener(watcher1);
                        String str1 = pound.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.010;
                        str1 = BigDecimal.valueOf(d1).toString();
                        india.setText("" + str1);
                        india.addTextChangedListener(watcher1);

                        us.removeTextChangedListener(watcher2);
                        String str2 = pound.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.68;
                        str2 = BigDecimal.valueOf(d2).toString();
                        us.setText("" + str2);
                        us.addTextChangedListener(watcher2);

                        euro.removeTextChangedListener(watcher3);
                        String str3 = pound.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.73;
                        str3 = BigDecimal.valueOf(d3).toString();
                        euro.setText("" + str3);
                        euro.addTextChangedListener(watcher3);

                        ausdollar.removeTextChangedListener(watcher4);
                        String str4 = pound.getText().toString();
                        double d4 = Double.parseDouble(str4) / 0.49;
                        str4 = BigDecimal.valueOf(d4).toString();
                        ausdollar.setText("" + str4);
                        ausdollar.addTextChangedListener(watcher4);

                        yan.removeTextChangedListener(watcher5);
                        String str5 = pound.getText().toString();
                        double d5 = Double.parseDouble(str5) / 0.0057;
                        str5 = BigDecimal.valueOf(d5).toString();
                        yan.setText("" + str5);
                        yan.addTextChangedListener(watcher5);

                        swiss.removeTextChangedListener(watcher7);
                        String str6 = pound.getText().toString();
                        double d6 = Double.parseDouble(str6) / 0.68;
                        str6 = BigDecimal.valueOf(d6).toString();
                        swiss.setText("" + str6);
                        swiss.addTextChangedListener(watcher7);

                        cdollar.removeTextChangedListener(watcher8);
                        String str7 = pound.getText().toString();
                        double d7 = Double.parseDouble(str7) / 0.49;
                        str7 = BigDecimal.valueOf(d7).toString();
                        cdollar.setText("" + str7);
                        cdollar.addTextChangedListener(watcher8);

                        sar.removeTextChangedListener(watcher9);
                        String str8 = pound.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.044;
                        str8 = BigDecimal.valueOf(d8).toString();
                        sar.setText("" + str8);
                        sar.addTextChangedListener(watcher9);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
                case R.id.editText7:
                    if(swiss.length()!=0)
                    {
                        india.removeTextChangedListener(watcher1);
                        String str1 = swiss.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.015;
                        str1 = BigDecimal.valueOf(d1).toString();
                        india.setText("" + str1);
                        india.addTextChangedListener(watcher1);

                        us.removeTextChangedListener(watcher2);
                        String str2 = swiss.getText().toString();
                        double d2 = Double.parseDouble(str2) / 1.01;
                        str2 = BigDecimal.valueOf(d2).toString();
                        us.setText("" + str2);
                        us.addTextChangedListener(watcher2);

                        euro.removeTextChangedListener(watcher3);
                        String str3 = swiss.getText().toString();
                        double d3 = Double.parseDouble(str3) / 1.08;
                        str3 = BigDecimal.valueOf(d3).toString();
                        euro.setText("" + str3);
                        euro.addTextChangedListener(watcher3);

                        ausdollar.removeTextChangedListener(watcher4);
                        String str4 = swiss.getText().toString();
                        double d4 = Double.parseDouble(str4) / 0.72;
                        str4 = BigDecimal.valueOf(d4).toString();
                        ausdollar.setText("" + str4);
                        ausdollar.addTextChangedListener(watcher4);

                        yan.removeTextChangedListener(watcher5);
                        String str5 = swiss.getText().toString();
                        double d5 = Double.parseDouble(str5) / 0.0085;
                        str5 = BigDecimal.valueOf(d5).toString();
                        yan.setText("" + str5);
                        yan.addTextChangedListener(watcher5);

                        pound.removeTextChangedListener(watcher6);
                        String str6 = swiss.getText().toString();
                        double d6 = Double.parseDouble(str6) / 1.48;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pound.setText("" + str6);
                        pound.addTextChangedListener(watcher6);

                        cdollar.removeTextChangedListener(watcher8);
                        String str7 = swiss.getText().toString();
                        double d7 = Double.parseDouble(str7) / 0.72;
                        str7 = BigDecimal.valueOf(d7).toString();
                        cdollar.setText("" + str7);
                        cdollar.addTextChangedListener(watcher8);

                        sar.removeTextChangedListener(watcher9);
                        String str8 = swiss.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.065;
                        str8 = BigDecimal.valueOf(d8).toString();
                        sar.setText("" + str8);
                        sar.addTextChangedListener(watcher9);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
                case R.id.editText8:
                    if(cdollar.length()!=0)
                    {
                        india.removeTextChangedListener(watcher1);
                        String str1 = cdollar.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.021;
                        str1 = BigDecimal.valueOf(d1).toString();
                        india.setText("" + str1);
                        india.addTextChangedListener(watcher1);

                        us.removeTextChangedListener(watcher2);
                        String str2 = cdollar.getText().toString();
                        double d2 = Double.parseDouble(str2) / 1.40;
                        str2 = BigDecimal.valueOf(d2).toString();
                        us.setText("" + str2);
                        us.addTextChangedListener(watcher2);

                        euro.removeTextChangedListener(watcher3);
                        String str3 = cdollar.getText().toString();
                        double d3 = Double.parseDouble(str3) / 1.50;
                        str3 = BigDecimal.valueOf(d3).toString();
                        euro.setText("" + str3);
                        euro.addTextChangedListener(watcher3);

                        ausdollar.removeTextChangedListener(watcher4);
                        String str4 = cdollar.getText().toString();
                        double d4 = Double.parseDouble(str4) / 1.00;
                        str4 = BigDecimal.valueOf(d4).toString();
                        ausdollar.setText("" + str4);
                        ausdollar.addTextChangedListener(watcher4);

                        yan.removeTextChangedListener(watcher5);
                        String str5 = cdollar.getText().toString();
                        double d5 = Double.parseDouble(str5) / 0.012;
                        str5 = BigDecimal.valueOf(d5).toString();
                        yan.setText("" + str5);
                        yan.addTextChangedListener(watcher5);

                        pound.removeTextChangedListener(watcher6);
                        String str6 = cdollar.getText().toString();
                        double d6 = Double.parseDouble(str6) / 2.05;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pound.setText("" + str6);
                        pound.addTextChangedListener(watcher6);

                        swiss.removeTextChangedListener(watcher7);
                        String str7 = cdollar.getText().toString();
                        double d7 = Double.parseDouble(str7) / 1.39;
                        str7 = BigDecimal.valueOf(d7).toString();
                        swiss.setText("" + str7);
                        swiss.addTextChangedListener(watcher7);

                        sar.removeTextChangedListener(watcher9);
                        String str8 = cdollar.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.090;
                        str8 = BigDecimal.valueOf(d8).toString();
                        sar.setText("" + str8);
                        sar.addTextChangedListener(watcher9);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
                case R.id.editText9:
                    if(sar.length()!=0)
                    {
                        india.removeTextChangedListener(watcher1);
                        String str1 = sar.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.24;
                        str1 = BigDecimal.valueOf(d1).toString();
                        india.setText("" + str1);
                        india.addTextChangedListener(watcher1);

                        us.removeTextChangedListener(watcher2);
                        String str2 = sar.getText().toString();
                        double d2 = Double.parseDouble(str2) / 15.63;
                        str2 = BigDecimal.valueOf(d2).toString();
                        us.setText("" + str2);
                        us.addTextChangedListener(watcher2);

                        euro.removeTextChangedListener(watcher3);
                        String str3 = sar.getText().toString();
                        double d3 = Double.parseDouble(str3) / 16.79;
                        str3 = BigDecimal.valueOf(d3).toString();
                        euro.setText("" + str3);
                        euro.addTextChangedListener(watcher3);

                        ausdollar.removeTextChangedListener(watcher4);
                        String str4 = sar.getText().toString();
                        double d4 = Double.parseDouble(str4) / 11.18;
                        str4 = BigDecimal.valueOf(d4).toString();
                        ausdollar.setText("" + str4);
                        ausdollar.addTextChangedListener(watcher4);

                        yan.removeTextChangedListener(watcher5);
                        String str5 = sar.getText().toString();
                        double d5 = Double.parseDouble(str5) / 0.13;
                        str5 = BigDecimal.valueOf(d5).toString();
                        yan.setText("" + str5);
                        yan.addTextChangedListener(watcher5);

                        pound.removeTextChangedListener(watcher6);
                        String str6 = sar.getText().toString();
                        double d6 = Double.parseDouble(str6) / 22.92;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pound.setText("" + str6);
                        pound.addTextChangedListener(watcher6);

                        swiss.removeTextChangedListener(watcher7);
                        String str7 = sar.getText().toString();
                        double d7 = Double.parseDouble(str7) / 15.48;
                        str7 = BigDecimal.valueOf(d7).toString();
                        swiss.setText("" + str7);
                        swiss.addTextChangedListener(watcher7);

                        cdollar.removeTextChangedListener(watcher8);
                        String str8 = sar.getText().toString();
                        double d8 = Double.parseDouble(str8) / 11.17;
                        str8 = BigDecimal.valueOf(d8).toString();
                        cdollar.setText("" + str8);
                        cdollar.addTextChangedListener(watcher8);
                    }
                    else
                    {
                        india.setText("0");
                        us.setText("0");
                        euro.setText("0");
                        ausdollar.setText("0");
                        yan.setText("0");
                        pound.setText("0");
                        swiss.setText("0");
                        cdollar.setText("0");
                        sar.setText("0");
                    }
                    break;
            }



            // TODO Auto-generated method stub

        }}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.currency, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.currency) {
                startActivity(new Intent(this,Currency.class));
            this.finish();

        } else if (id == R.id.area) {
                startActivity(new Intent(this,Area.class));
            this.finish();
        }
        else if (id == R.id.angle) {
            startActivity(new Intent(this, Angle.class));
            this.finish();
        }
        else if (id == R.id.storage) {
            startActivity(new Intent(this, Data_Storage.class));
            this.finish();
        }
        else if (id == R.id.astronomical) {
            startActivity(new Intent(this, Astronomical.class));
            this.finish();
        }
        else if (id == R.id.capture) {
            Intent i=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            startActivity(i);
        }
        else if (id == R.id.gallary) {
            Intent i=new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            startActivity(i);
        }
        else if (id == R.id.calulater) {
            startActivity(new Intent(this, Calculate.class));
            this.finish();
        }

        else if (id == R.id.flash) {
            startActivity(new Intent(this, Flash.class));
            this.finish();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
