package com.example.puneetgoyal.converter;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

import java.math.BigDecimal;

public class Data_Storage extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    EditText bit,byt,kbyte,mbyte,gbyte,tbyte,pbyte;
    private CustomWatcher watcher0,watcher1,watcher2,watcher3,watcher4,watcher5,watcher6;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data__storage);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.colorDigitalDark));
        }
        bit = (EditText) findViewById(R.id.editText0);
        byt = (EditText) findViewById(R.id.editText1);
        kbyte = (EditText) findViewById(R.id.editText2);
        mbyte = (EditText) findViewById(R.id.editText3);
        gbyte = (EditText) findViewById(R.id.editText4);
        tbyte = (EditText) findViewById(R.id.editText5);
        pbyte = (EditText) findViewById(R.id.editText6);

        watcher0=new CustomWatcher(bit);
        watcher1=new CustomWatcher(byt);
        watcher2=new CustomWatcher(kbyte);
        watcher3=new CustomWatcher(mbyte);
        watcher4=new CustomWatcher(gbyte);
        watcher5=new CustomWatcher(tbyte);
        watcher6=new CustomWatcher(pbyte);

        bit.addTextChangedListener(watcher0);
        byt.addTextChangedListener(watcher1);
        kbyte.addTextChangedListener(watcher2);
        mbyte.addTextChangedListener(watcher3);
        gbyte.addTextChangedListener(watcher4);
        tbyte.addTextChangedListener(watcher5);
        pbyte.addTextChangedListener(watcher6);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setBackgroundTintList(getResources().getColorStateList(R.color.colorDigital));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }
    public	class CustomWatcher implements TextWatcher {
        private View view;
        public CustomWatcher(View view) {
            this.view = view;
        }

        @Override
        public void afterTextChanged(Editable arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                  int arg3) {

            switch (view.getId()) {
                case R.id.editText0:
                    if (bit.length() != 0) {
                        byt.removeTextChangedListener(watcher1);
                        String str1 = bit.getText().toString();
                        double d1 = Double.parseDouble(str1) / 8;
                        str1 = BigDecimal.valueOf(d1).toString();
                        byt.setText("" + str1);
                        byt.addTextChangedListener(watcher1);

                        kbyte.removeTextChangedListener(watcher2);
                        String str2 = bit.getText().toString();
                        double d2 = Double.parseDouble(str2) / 8192;
                        str2 = BigDecimal.valueOf(d2).toString();
                        kbyte.setText("" + str2);
                        kbyte.addTextChangedListener(watcher2);

                        mbyte.removeTextChangedListener(watcher3);
                        String str3 = bit.getText().toString();
                        double d3 = Double.parseDouble(str3) / 8388608;
                        str3 = BigDecimal.valueOf(d3).toString();
                        mbyte.setText("" + str3);
                        mbyte.addTextChangedListener(watcher3);

                        gbyte.removeTextChangedListener(watcher4);
                        String str4 = bit.getText().toString();
                        double d4 = Double.parseDouble(str4) / 85899345.92*100;
                        str4 = BigDecimal.valueOf(d4).toString();
                        gbyte.setText("" + str4);
                        gbyte.addTextChangedListener(watcher4);

                        tbyte.removeTextChangedListener(watcher5);
                        String str5 = bit.getText().toString();
                        double d5 = Double.parseDouble(str5) / 87957552652.06*100;
                        str5 = BigDecimal.valueOf(d5).toString();
                        tbyte.setText("" + str5);
                        tbyte.addTextChangedListener(watcher5);

                        pbyte.removeTextChangedListener(watcher6);
                        String str6 = bit.getText().toString();
                        double d6 = Double.parseDouble(str6) / 3386205821.701;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pbyte.setText("" + str6);
                        pbyte.addTextChangedListener(watcher6);



                    } else {
                        bit.setText("0");
                        byt.setText("0");
                        kbyte.setText("0");
                        mbyte.setText("0");
                        gbyte.setText("0");
                        tbyte.setText("0");
                        pbyte.setText("0");
                       }
                    break;
                case R.id.editText1:
                    if (byt.length() != 0) {
                        bit.removeTextChangedListener(watcher0);
                        String str1 = byt.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.125;
                        str1 = BigDecimal.valueOf(d1).toString();
                        bit.setText("" + str1);
                        bit.addTextChangedListener(watcher0);

                        kbyte.removeTextChangedListener(watcher2);
                        String str2 = byt.getText().toString();
                        double d2 = Double.parseDouble(str2) / 1024;
                        str2 = BigDecimal.valueOf(d2).toString();
                        kbyte.setText("" + str2);
                        kbyte.addTextChangedListener(watcher2);

                        mbyte.removeTextChangedListener(watcher3);
                        String str3 = byt.getText().toString();
                        double d3 = Double.parseDouble(str3) / 1048576;
                        str3 = BigDecimal.valueOf(d3).toString();
                        mbyte.setText("" + str3);
                        mbyte.addTextChangedListener(watcher3);

                        gbyte.removeTextChangedListener(watcher4);
                        String str4 = byt.getText().toString();
                        double d4 = Double.parseDouble(str4) / 1073741824;
                        str4 = BigDecimal.valueOf(d4).toString();
                        gbyte.setText("" + str4);
                        gbyte.addTextChangedListener(watcher4);

                        tbyte.removeTextChangedListener(watcher5);
                        String str5 = byt.getText().toString();
                        double d5 = Double.parseDouble(str5) /1374389534.72*100;
                        str5 = BigDecimal.valueOf(d5).toString();
                        tbyte.setText("" + str5);
                        tbyte.addTextChangedListener(watcher5);

                        pbyte.removeTextChangedListener(watcher6);
                        String str6 = byt.getText().toString();
                        double d6 = Double.parseDouble(str6) / 423275727.7126;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pbyte.setText("" + str6);
                        pbyte.addTextChangedListener(watcher6);
                    } else {
                        bit.setText("0");
                        byt.setText("0");
                        kbyte.setText("0");
                        mbyte.setText("0");
                        gbyte.setText("0");
                        tbyte.setText("0");
                        pbyte.setText("0");
                    }
                    break;
                case R.id.editText2:
                    if (kbyte.length() != 0) {
                        bit.removeTextChangedListener(watcher0);
                        String str1 = kbyte.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.0001220703125;
                        str1 = BigDecimal.valueOf(d1).toString();
                        bit.setText("" + str1);
                        bit.addTextChangedListener(watcher0);

                        byt.removeTextChangedListener(watcher1);
                        String str2 = kbyte.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.0009765625;
                        str2 = BigDecimal.valueOf(d2).toString();
                        byt.setText("" + str2);
                        byt.addTextChangedListener(watcher1);

                        mbyte.removeTextChangedListener(watcher3);
                        String str3 = kbyte.getText().toString();
                        double d3 = Double.parseDouble(str3) / 1024;
                        str3 = BigDecimal.valueOf(d3).toString();
                        mbyte.setText("" + str3);
                        mbyte.addTextChangedListener(watcher3);

                        gbyte.removeTextChangedListener(watcher4);
                        String str4 = kbyte.getText().toString();
                        double d4 = Double.parseDouble(str4) / 1048576;
                        str4 = BigDecimal.valueOf(d4).toString();
                        gbyte.setText("" + str4);
                        gbyte.addTextChangedListener(watcher4);

                        tbyte.removeTextChangedListener(watcher5);
                        String str5 = kbyte.getText().toString();
                        double d5 = Double.parseDouble(str5) /1073700593.897;
                        str5 = BigDecimal.valueOf(d5).toString();
                        tbyte.setText("" + str5);
                        tbyte.addTextChangedListener(watcher5);

                        pbyte.removeTextChangedListener(watcher6);
                        String str6 = kbyte.getText().toString();
                        double d6 = Double.parseDouble(str6) / 413355.2028443;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pbyte.setText("" + str6);
                        pbyte.addTextChangedListener(watcher6);


                    } else {
                        bit.setText("0");
                        byt.setText("0");
                        kbyte.setText("0");
                        mbyte.setText("0");
                        gbyte.setText("0");
                        tbyte.setText("0");
                        pbyte.setText("0");
                        }
                    break;
                case R.id.editText3:
                    if (mbyte.length() != 0) {
                        bit.removeTextChangedListener(watcher0);
                        String str1 = mbyte.getText().toString();
                        double d1 = Double.parseDouble(str1) *8388608;
                        str1 = BigDecimal.valueOf(d1).toString();
                        bit.setText("" + str1);
                        bit.addTextChangedListener(watcher0);

                        byt.removeTextChangedListener(watcher1);
                        String str2 = mbyte.getText().toString();
                        double d2 = Double.parseDouble(str2) *1048576;
                        str2 = BigDecimal.valueOf(d2).toString();
                        byt.setText("" + str2);
                        byt.addTextChangedListener(watcher1);

                        kbyte.removeTextChangedListener(watcher2);
                        String str3 = mbyte.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.0009765625;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kbyte.setText("" + str3);
                        kbyte.addTextChangedListener(watcher2);

                        gbyte.removeTextChangedListener(watcher4);
                        String str4 = mbyte.getText().toString();
                        double d4 = Double.parseDouble(str4) /1024;
                        str4 = BigDecimal.valueOf(d4).toString();
                        gbyte.setText("" + str4);
                        gbyte.addTextChangedListener(watcher4);

                        tbyte.removeTextChangedListener(watcher5);
                        String str5 = mbyte.getText().toString();
                        double d5 = Double.parseDouble(str5) / 1048535.936228;
                        str5 = BigDecimal.valueOf(d5).toString();
                        tbyte.setText("" + str5);
                        tbyte.addTextChangedListener(watcher5);

                        pbyte.removeTextChangedListener(watcher6);
                        String str6 = mbyte.getText().toString();
                        double d6 = Double.parseDouble(str6) / 403.6671902777;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pbyte.setText("" + str6);
                        pbyte.addTextChangedListener(watcher6);


                    } else {
                        bit.setText("0");
                        byt.setText("0");
                        kbyte.setText("0");
                        mbyte.setText("0");
                        gbyte.setText("0");
                        tbyte.setText("0");
                        pbyte.setText("0");
                        }
                    break;
                case R.id.editText4:
                    if (gbyte.length() != 0) {
                        bit.removeTextChangedListener(watcher0);
                        String str1 = gbyte.getText().toString();
                        double d1 = Double.parseDouble(str1) *85899345.92*100;
                        str1 = BigDecimal.valueOf(d1).toString();
                        bit.setText("" + str1);
                        bit.addTextChangedListener(watcher0);

                        byt.removeTextChangedListener(watcher1);
                        String str2 = gbyte.getText().toString();
                        double d2 = Double.parseDouble(str2) *1073741824;
                        str2 = BigDecimal.valueOf(d2).toString();
                        byt.setText("" + str2);
                        byt.addTextChangedListener(watcher1);

                        kbyte.removeTextChangedListener(watcher2);
                        String str3 = gbyte.getText().toString();
                        double d3 = Double.parseDouble(str3) *1048576;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kbyte.setText("" + str3);
                        kbyte.addTextChangedListener(watcher2);

                        mbyte.removeTextChangedListener(watcher3);
                        String str4 = gbyte.getText().toString();
                        double d4 = Double.parseDouble(str4) /0.0078125 ;
                        str4 = BigDecimal.valueOf(d4).toString();
                        mbyte.setText("" + str4);
                        mbyte.addTextChangedListener(watcher3);

                        tbyte.removeTextChangedListener(watcher5);
                        String str5 = gbyte.getText().toString();
                        double d5 = Double.parseDouble(str5) / 8191.685439279;
                        str5 = BigDecimal.valueOf(d5).toString();
                        tbyte.setText("" + str5);
                        tbyte.addTextChangedListener(watcher5);

                        pbyte.removeTextChangedListener(watcher6);
                        String str6 = gbyte.getText().toString();
                        double d6 = Double.parseDouble(str6) / 3.153649924044;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pbyte.setText("" + str6);
                        pbyte.addTextChangedListener(watcher6);


                    } else {
                        bit.setText("0");
                        byt.setText("0");
                        kbyte.setText("0");
                        mbyte.setText("0");
                        gbyte.setText("0");
                        tbyte.setText("0");
                        pbyte.setText("0");
                        }
                    break;
                case R.id.editText5:
                    if (tbyte.length() != 0) {
                        bit.removeTextChangedListener(watcher0);
                        String str1 = tbyte.getText().toString();
                        double d1 = Double.parseDouble(str1) * 8795755265.206*1000;
                        str1 = BigDecimal.valueOf(d1).toString();
                        bit.setText("" + str1);
                        bit.addTextChangedListener(watcher0);

                        byt.removeTextChangedListener(watcher1);
                        String str2 = tbyte.getText().toString();
                        double d2 = Double.parseDouble(str2) * 109946940814.51*100;
                        str2 = BigDecimal.valueOf(d2).toString();
                        byt.setText("" + str2);
                        byt.addTextChangedListener(watcher1);

                        kbyte.removeTextChangedListener(watcher2);
                        String str3 = tbyte.getText().toString();
                        double d3 = Double.parseDouble(str3) * 1073700593.897;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kbyte.setText("" + str3);
                        kbyte.addTextChangedListener(watcher2);

                        mbyte.removeTextChangedListener(watcher3);
                        String str4 = tbyte.getText().toString();
                        double d4 = Double.parseDouble(str4) *1048535.736228;
                        str4 = BigDecimal.valueOf(d4).toString();
                        mbyte.setText("" + str4);
                        mbyte.addTextChangedListener(watcher3);

                        gbyte.removeTextChangedListener(watcher4);
                        String str5 = tbyte.getText().toString();
                        double d5 = Double.parseDouble(str5) / 0.009766;
                        str5 = BigDecimal.valueOf(d5).toString();
                        gbyte.setText("" + str5);
                        gbyte.addTextChangedListener(watcher4);

                        pbyte.removeTextChangedListener(watcher6);
                        String str6 = tbyte.getText().toString();
                        double d6 = Double.parseDouble(str6) / 0.0003849818144777;
                        str6 = BigDecimal.valueOf(d6).toString();
                        pbyte.setText("" + str6);
                        pbyte.addTextChangedListener(watcher6);

                    } else {
                        bit.setText("0");
                        byt.setText("0");
                        kbyte.setText("0");
                        mbyte.setText("0");
                        gbyte.setText("0");
                        tbyte.setText("0");
                        pbyte.setText("0");
                            }
                    break;
                case R.id.editText6:
                    if (pbyte.length() != 0) {
                        bit.removeTextChangedListener(watcher0);
                        String str1 = pbyte.getText().toString();
                        double d1 = Double.parseDouble(str1) * 3386205821.701;
                        str1 = BigDecimal.valueOf(d1).toString();
                        bit.setText("" + str1);
                        bit.addTextChangedListener(watcher0);

                        byt.removeTextChangedListener(watcher1);
                        String str2 = pbyte.getText().toString();
                        double d2 = Double.parseDouble(str2) * 423275727.7126;
                        str2 = BigDecimal.valueOf(d2).toString();
                        byt.setText("" + str2);
                        byt.addTextChangedListener(watcher1);

                        kbyte.removeTextChangedListener(watcher2);
                        String str3 = pbyte.getText().toString();
                        double d3 = Double.parseDouble(str3) * 413355.2028443;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kbyte.setText("" + str3);
                        kbyte.addTextChangedListener(watcher2);

                        mbyte.removeTextChangedListener(watcher3);
                        String str4 = pbyte.getText().toString();
                        double d4 = Double.parseDouble(str4) * 403.6671902777;
                        str4 = BigDecimal.valueOf(d4).toString();
                        mbyte.setText("" + str4);
                        mbyte.addTextChangedListener(watcher3);

                        gbyte.removeTextChangedListener(watcher4);
                        String str5 = pbyte.getText().toString();
                        double d5 = Double.parseDouble(str5) / 2.5367432;
                        str5 = BigDecimal.valueOf(d5).toString();
                        gbyte.setText("" + str5);
                        gbyte.addTextChangedListener(watcher4);

                        tbyte.removeTextChangedListener(watcher5);
                        String str6 = pbyte.getText().toString();
                        double d6 = Double.parseDouble(str6) / 2597.5252291829;
                        str6 = BigDecimal.valueOf(d6).toString();
                        tbyte.setText("" + str6);
                        tbyte.addTextChangedListener(watcher5);


                    } else {
                        bit.setText("0");
                        byt.setText("0");
                        kbyte.setText("0");
                        mbyte.setText("0");
                        gbyte.setText("0");
                        tbyte.setText("0");
                        pbyte.setText("0");
                        }
                    break;
            }
        }}

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.data__storage, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.currency) {
            startActivity(new Intent(this,Currency.class));
            this.finish();
        } else if (id == R.id.area) {
            startActivity(new Intent(this,Area.class));
            this.finish();
        }
        else if (id == R.id.angle) {
            startActivity(new Intent(this, Angle.class));
            this.finish();
        }
        else if (id == R.id.storage) {
            startActivity(new Intent(this, Data_Storage.class));
            this.finish();
        }
        else if (id == R.id.astronomical) {
            startActivity(new Intent(this, Astronomical.class));
            this.finish();
        }
        else if (id == R.id.capture) {
            Intent i=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            startActivity(i);
        }
        else if (id == R.id.gallary) {
            Intent i=new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            startActivity(i);
        }
        else if (id == R.id.calulater) {
            startActivity(new Intent(this, Calculate.class));
            this.finish();
        }

        else if (id == R.id.flash) {
            startActivity(new Intent(this, Flash.class));
            this.finish();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
