package com.example.puneetgoyal.converter;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import java.math.BigDecimal;

public class Angle extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    TextView t,t1,t2,t3;
    EditText degree, circle, grad,radians;
   private CustomWatcher watcher0,watcher1,watcher2,watcher3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_angle);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.colorAngleDark));
        }
        degree = (EditText) findViewById(R.id.editText0);
        circle = (EditText) findViewById(R.id.editText1);
        grad = (EditText) findViewById(R.id.editText2);
        radians = (EditText) findViewById(R.id.editText3);

        watcher0=new CustomWatcher(degree);
        watcher1=new CustomWatcher(circle);
        watcher2=new CustomWatcher(grad);
        watcher3=new CustomWatcher(radians);


        degree.addTextChangedListener(watcher0);
        circle.addTextChangedListener(watcher1);
        grad.addTextChangedListener(watcher2);
        radians.addTextChangedListener(watcher3);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setBackgroundTintList(getResources().getColorStateList(R.color.colorAngle));
        //fab.setBackgroundTintList(ColorStateList.valueOf(9C27B0));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
//                ImageView Cal = new ImageView(Angle.this); // Create an icon
//       Cal.setImageResource(R.drawable.ic_menu_send);
//                ImageView Notes = new ImageView(Angle.this); // Create an icon
//                Notes.setImageResource(R.drawable.ic_menu_manage);
//
//                SubActionButton.Builder itemBuilder = new SubActionButton.Builder(Angle.this);
//
//                SubActionButton Calbutton = itemBuilder.setContentView(Cal).build();
//                SubActionButton Notebutton = itemBuilder.setContentView(Notes).build();
//
//                FloatingActionMenu actionMenu = new FloatingActionMenu.Builder(Angle.this).addSubActionView(Cal)
//                        .addSubActionView(Notes).attachTo(fab).build();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    public	class CustomWatcher implements TextWatcher {
        private View view;
        public CustomWatcher(View view) {
            this.view = view;
        }

        @Override
        public void afterTextChanged(Editable arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                  int arg3) {

            switch (view.getId()) {
                case R.id.editText0:
                    if (degree.length() != 0) {
                        circle.removeTextChangedListener(watcher1);
                        String str1 = degree.getText().toString();
                        double d1 = Double.parseDouble(str1) / 360;
                        str1 = BigDecimal.valueOf(d1).toString();
                        circle.setText("" + str1);
                        circle.addTextChangedListener(watcher1);

                        grad.removeTextChangedListener(watcher2);
                        String str2 = degree.getText().toString();
                        double d2 = Double.parseDouble(str2) /0.9;
                        str2 = BigDecimal.valueOf(d2).toString();
                        grad.setText("" + str2);
                        grad.addTextChangedListener(watcher2);

                        radians.removeTextChangedListener(watcher3);
                        String str3 = degree.getText().toString();
                        double d3 = Double.parseDouble(str3) / 57.29577951308;
                        str3 = BigDecimal.valueOf(d3).toString();
                        radians.setText("" + str3);
                        radians.addTextChangedListener(watcher3);


                    } else {
                        degree.setText("0");
                        circle.setText("0");
                        grad.setText("0");
                        radians.setText("0");
                    }
                    break;
                case R.id.editText1:
                    if (circle.length() != 0) {
                        degree.removeTextChangedListener(watcher0);
                        String str1 = circle.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.002777777777778;
                        str1 = BigDecimal.valueOf(d1).toString();
                        degree.setText("" + str1);
                        degree.addTextChangedListener(watcher0);

                        grad.removeTextChangedListener(watcher2);
                        String str2 = circle.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.0025;
                        str2 = BigDecimal.valueOf(d2).toString();
                        grad.setText("" + str2);
                        grad.addTextChangedListener(watcher2);

                        radians.removeTextChangedListener(watcher3);
                        String str3 = circle.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.1591549430919;
                        str3 = BigDecimal.valueOf(d3).toString();
                        radians.setText("" + str3);
                        radians.addTextChangedListener(watcher3);
                    } else {
                        degree.setText("0");
                        circle.setText("0");
                        grad.setText("0");
                        radians.setText("0");
                    }
                    break;
                case R.id.editText2:
                    if (grad.length() != 0) {
                        degree.removeTextChangedListener(watcher0);
                        String str1 = grad.getText().toString();
                        double d1 = Double.parseDouble(str1) / 1.111111111111;
                        str1 = BigDecimal.valueOf(d1).toString();
                        degree.setText("" + str1);
                        degree.addTextChangedListener(watcher0);

                        circle.removeTextChangedListener(watcher1);
                        String str2 = grad.getText().toString();
                        double d2 = Double.parseDouble(str2) / 400;
                        str2 = BigDecimal.valueOf(d2).toString();
                        circle.setText("" + str2);
                        circle.addTextChangedListener(watcher1);

                        radians.removeTextChangedListener(watcher3);
                        String str3 = grad.getText().toString();
                        double d3 = Double.parseDouble(str3) / 63.66197723676;
                        str3 = BigDecimal.valueOf(d3).toString();
                        radians.setText("" + str3);
                        radians.addTextChangedListener(watcher3);
                    } else {
                        degree.setText("0");
                        circle.setText("0");
                        grad.setText("0");
                        radians.setText("0");
                    }
                    break;
                case R.id.editText3:
                    if (radians.length() != 0) {
                        degree.removeTextChangedListener(watcher0);
                        String str1 = radians.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.01745329251994;
                        str1 = BigDecimal.valueOf(d1).toString();
                        degree.setText("" + str1);
                        degree.addTextChangedListener(watcher0);

                        circle.removeTextChangedListener(watcher1);
                        String str2 = radians.getText().toString();
                        double d2 = Double.parseDouble(str2) / 6.283185307179;
                        str2 = BigDecimal.valueOf(d2).toString();
                        circle.setText("" + str2);
                        circle.addTextChangedListener(watcher1);

                        grad.removeTextChangedListener(watcher2);
                        String str3 = radians.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.001570796326795;
                        str3 = BigDecimal.valueOf(d3).toString();
                        grad.setText("" + str3);
                        grad.addTextChangedListener(watcher2);
                    } else {
                        degree.setText("0");
                        circle.setText("0");
                        grad.setText("0");
                        radians.setText("0");
                    }
                    break;
            }
        }}

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.angle, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.currency) {
            startActivity(new Intent(this,Currency.class));
            this.finish();
        } else if (id == R.id.area) {
            startActivity(new Intent(this,Area.class));
            this.finish();
        }
        else if (id == R.id.angle) {
            startActivity(new Intent(this, Angle.class));
            this.finish();
        }
        else if (id == R.id.storage) {
            startActivity(new Intent(this, Data_Storage.class));
            this.finish();
        }
        else if (id == R.id.astronomical) {
            startActivity(new Intent(this, Astronomical.class));
            this.finish();
        }
        else if (id == R.id.capture) {
            Intent i=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            startActivity(i);
        }
        else if (id == R.id.gallary) {
            Intent i=new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            startActivity(i);
        }
        else if (id == R.id.calulater) {
            startActivity(new Intent(this, Calculate.class));
            this.finish();
        }
        else if (id == R.id.flash) {
            startActivity(new Intent(this, Flash.class));
            this.finish();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
