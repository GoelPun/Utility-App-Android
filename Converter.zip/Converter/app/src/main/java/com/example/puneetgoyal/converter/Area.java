package com.example.puneetgoyal.converter;

import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import java.math.BigDecimal;
import android.content.Intent;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

public class Area extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    TextView t,t1,t2,t3,t4,t5,t6,t7,t8,t9;
    EditText acre, hectaer, homestead,rood, centimeter, foot, inch, kilometer,meter,mile,milimeter,rod,yard,township;
    private CustomWatcher watcher0,watcher1,watcher2,watcher3,watcher4,watcher5,watcher6,watcher7,watcher8,watcher9,watcher10,watcher11,watcher12,watcher13;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.colorAreaDark));
        }
        acre = (EditText) findViewById(R.id.editText0);
        hectaer = (EditText) findViewById(R.id.editText1);
        homestead = (EditText) findViewById(R.id.editText2);
        rood = (EditText) findViewById(R.id.editText3);
        centimeter = (EditText) findViewById(R.id.editText4);
        foot = (EditText) findViewById(R.id.editText5);
        inch = (EditText) findViewById(R.id.editText6);
        kilometer = (EditText) findViewById(R.id.editText7);
        meter = (EditText) findViewById(R.id.editText8);
        mile = (EditText) findViewById(R.id.editText9);
        milimeter = (EditText) findViewById(R.id.editText10);
        rod = (EditText) findViewById(R.id.editText11);
        yard = (EditText) findViewById(R.id.editText12);
        township = (EditText) findViewById(R.id.editText13);
        watcher0=new CustomWatcher(acre);
        watcher1=new CustomWatcher(hectaer);
        watcher2=new CustomWatcher(homestead);
        watcher3=new CustomWatcher(rood);
        watcher4=new CustomWatcher(centimeter);
        watcher5=new CustomWatcher(foot);
        watcher6=new CustomWatcher(inch);
        watcher7=new CustomWatcher(kilometer);
        watcher8=new CustomWatcher(meter);
        watcher9=new CustomWatcher(mile);
        watcher10=new CustomWatcher(milimeter);
        watcher11=new CustomWatcher(rod);
        watcher12=new CustomWatcher(yard);
        watcher13=new CustomWatcher(township);

        acre.addTextChangedListener(watcher0);
        hectaer.addTextChangedListener(watcher1);
        homestead.addTextChangedListener(watcher2);
        rood.addTextChangedListener(watcher3);
        centimeter.addTextChangedListener(watcher4);
        foot.addTextChangedListener(watcher5);
        inch.addTextChangedListener(watcher6);
        kilometer.addTextChangedListener(watcher7);
        meter.addTextChangedListener(watcher8);
        mile.addTextChangedListener(watcher9);
        milimeter.addTextChangedListener(watcher10);
        rod.addTextChangedListener(watcher11);
        yard.addTextChangedListener(watcher12);
        township.addTextChangedListener(watcher13);
        t=(TextView)findViewById(R.id.textView4);
        t.setText(Html.fromHtml("Square Centimeter(cm<sup><small>2</small></sup>)"));
        t1=(TextView)findViewById(R.id.textView5);
        t1.setText(Html.fromHtml("Square Foot(ft<sup><small>2</small></sup>)"));
        t2=(TextView)findViewById(R.id.textView6);
        t2.setText(Html.fromHtml("Square Inch(in<sup><small>2</small></sup>)"));
        t3=(TextView)findViewById(R.id.textView7);
        t3.setText(Html.fromHtml("Square Kilo Meter(km<sup><small>2</small></sup>)"));
        t4=(TextView)findViewById(R.id.textView8);
        t4.setText(Html.fromHtml("Square Meter(m<sup><small>2</small></sup>)"));
        t5=(TextView)findViewById(R.id.textView10);
        t5.setText(Html.fromHtml("Square Mili Meter(mm<sup><small>2</small></sup>)"));
        t6=(TextView)findViewById(R.id.textView12);
        t6.setText(Html.fromHtml("Square Yard(yd<sup><small>2</small></sup>)"));


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setBackgroundTintList(getResources().getColorStateList(R.color.colorArea));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    public	class CustomWatcher implements TextWatcher{
        private View view;
        public CustomWatcher(View view) {
            this.view = view;
        }

        @Override
        public void afterTextChanged(Editable arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                  int arg3) {

            switch(view.getId())
            {
                case R.id.editText0:
                    if(acre.length()!=0)
                    {
                        hectaer.removeTextChangedListener(watcher1);
                        String str1 = acre.getText().toString();
                        double d1 = Double.parseDouble(str1) /2.41703814672;
                        str1 = BigDecimal.valueOf(d1).toString();
                        hectaer.setText("" + str1);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str2 = acre.getText().toString();
                        double d2 = Double.parseDouble(str2) / 160;
                        str2 = BigDecimal.valueOf(d2).toString();
                        homestead.setText("" + str2);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str3 = acre.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.25;
                        str3 = BigDecimal.valueOf(d3).toString();
                        rood.setText("" + str3);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str4 = acre.getText().toString();
                        double d4 = Double.parseDouble(str4) *40468564.224;
                        str4 = BigDecimal.valueOf(d4).toString();
                        centimeter.setText("" + str4);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str5 = acre.getText().toString();
                        double d5 = Double.parseDouble(str5) *43560;
                        str5 = BigDecimal.valueOf(d5).toString();
                        foot.setText("" + str5);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str6 = acre.getText().toString();
                        double d6 = Double.parseDouble(str6) *6272640;
                        str6 = BigDecimal.valueOf(d6).toString();
                        inch.setText("" + str6);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str7 = acre.getText().toString();
                        double d7 = Double.parseDouble(str7) / 247.1053814672;
                        str7 = BigDecimal.valueOf(d7).toString();
                        kilometer.setText("" + str7);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str8 = acre.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.0002471053814672;
                        str8 = BigDecimal.valueOf(d8).toString();
                        meter.setText("" + str8);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = acre.getText().toString();
                        double d9 = Double.parseDouble(str9) / 640;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = acre.getText().toString();
                        double d10 = Double.parseDouble(str10) / 2.4171053814672;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = acre.getText().toString();
                        double d11= Double.parseDouble(str11) / 0.00625;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = acre.getText().toString();
                        double d12 = Double.parseDouble(str12) / 0.0002066115702479;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = acre.getText().toString();
                        double d13 = Double.parseDouble(str13) / 23040;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);

                    }
                    else
                    {	acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText1:
                    if(hectaer.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = hectaer.getText().toString();
                        double d1 = Double.parseDouble(str1) /0.40468564224;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        homestead.removeTextChangedListener(watcher2);
                        String str2 = hectaer.getText().toString();
                        double d2 = Double.parseDouble(str2) / 64.7490247584;
                        str2 = BigDecimal.valueOf(d2).toString();
                        homestead.setText("" + str2);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str3 = hectaer.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.10117141056;
                        str3 = BigDecimal.valueOf(d3).toString();
                        rood.setText("" + str3);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str4 = hectaer.getText().toString();
                        double d4 = Double.parseDouble(str4) *100000000;
                        str4 = BigDecimal.valueOf(d4).toString();
                        centimeter.setText("" + str4);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str5 = hectaer.getText().toString();
                        double d5 = Double.parseDouble(str5)/0.000009290304;
                        str5 = BigDecimal.valueOf(d5).toString();
                        foot.setText("" + str5);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str6 = hectaer.getText().toString();
                        double d6 = Double.parseDouble(str6)*15500031.00006;
                        str6 = BigDecimal.valueOf(d6).toString();
                        inch.setText("" + str6);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str7 = hectaer.getText().toString();
                        double d7 = Double.parseDouble(str7) /100;
                        str7 = BigDecimal.valueOf(d7).toString();
                        kilometer.setText("" + str7);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str8 = hectaer.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.0001;
                        str8 = BigDecimal.valueOf(d8).toString();
                        meter.setText("" + str8);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = hectaer.getText().toString();
                        double d9 = Double.parseDouble(str9) / 258.9988110336;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = hectaer.getText().toString();
                        double d10 = Double.parseDouble(str10) / 100000000;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = hectaer.getText().toString();
                        double d11= Double.parseDouble(str11) / 0.002529285264;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = hectaer.getText().toString();
                        double d12 = Double.parseDouble(str12) / 0.000083612736;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = hectaer.getText().toString();
                        double d13 = Double.parseDouble(str13) / 9323.95719721;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText2:
                    if(homestead.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = homestead.getText().toString();
                        double d1 = Double.parseDouble(str1) /0.00625;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = homestead.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.0154440863417;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        rood.removeTextChangedListener(watcher3);
                        String str3 = homestead.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.0015625;
                        str3 = BigDecimal.valueOf(d3).toString();
                        rood.setText("" + str3);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str4 = homestead.getText().toString();
                        double d4 = Double.parseDouble(str4) *6474970275.84;
                        str4 = BigDecimal.valueOf(d4).toString();
                        centimeter.setText("" + str4);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str5 = homestead.getText().toString();
                        double d5 = Double.parseDouble(str5) *6969600;
                        str5 = BigDecimal.valueOf(d5).toString();
                        foot.setText("" + str5);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str6 = homestead.getText().toString();
                        double d6 = Double.parseDouble(str6) *1003622400;
                        str6 = BigDecimal.valueOf(d6).toString();
                        inch.setText("" + str6);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str7 = homestead.getText().toString();
                        double d7 = Double.parseDouble(str7) / 1.54440863417;
                        str7 = BigDecimal.valueOf(d7).toString();
                        kilometer.setText("" + str7);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str8 = homestead.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.00000154440863417;
                        str8 = BigDecimal.valueOf(d8).toString();
                        meter.setText("" + str8);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = homestead.getText().toString();
                        double d9 = Double.parseDouble(str9) / 4;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = homestead.getText().toString();
                        double d10 = Double.parseDouble(str10) *647497.027584*1000000;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = homestead.getText().toString();
                        double d11= Double.parseDouble(str11) / 0.0000390625;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = homestead.getText().toString();
                        double d12 = Double.parseDouble(str12) / 0.00000129132231405;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = homestead.getText().toString();
                        double d13 = Double.parseDouble(str13) / 144;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText3:
                    if(rood.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = rood.getText().toString();
                        double d1 = Double.parseDouble(str1) /4;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = rood.getText().toString();
                        double d2 = Double.parseDouble(str2) /9.884215258687;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = rood.getText().toString();
                        double d3 = Double.parseDouble(str3) / 640;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        centimeter.removeTextChangedListener(watcher4);
                        String str4 = rood.getText().toString();
                        double d4 = Double.parseDouble(str4) *10117141.056;
                        str4 = BigDecimal.valueOf(d4).toString();
                        centimeter.setText("" + str4);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str5 = rood.getText().toString();
                        double d5 = Double.parseDouble(str5)/0.00009182736455463;
                        str5 = BigDecimal.valueOf(d5).toString();
                        foot.setText("" + str5);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str6 = rood.getText().toString();
                        double d6 = Double.parseDouble(str6) *1568160;
                        str6 = BigDecimal.valueOf(d6).toString();
                        inch.setText("" + str6);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str7 = rood.getText().toString();
                        double d7 = Double.parseDouble(str7) / 988.4215258687;
                        str7 = BigDecimal.valueOf(d7).toString();
                        kilometer.setText("" + str7);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str8 = rood.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.0009884215258687;
                        str8 = BigDecimal.valueOf(d8).toString();
                        meter.setText("" + str8);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = rood.getText().toString();
                        double d9 = Double.parseDouble(str9) / 2560;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = rood.getText().toString();
                        double d10 = Double.parseDouble(str10) *1011714105.6;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = rood.getText().toString();
                        double d11= Double.parseDouble(str11) / 0.025;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = rood.getText().toString();
                        double d12 = Double.parseDouble(str12) / 0.0008264462809917;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = rood.getText().toString();
                        double d13 = Double.parseDouble(str13) / 92160;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText4:
                    if(centimeter.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = centimeter.getText().toString();
                        double d1 = Double.parseDouble(str1) /40468564.224;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = centimeter.getText().toString();
                        double d2 = Double.parseDouble(str2) /100000000;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = centimeter.getText().toString();
                        double d3 = Double.parseDouble(str3) / 6474970247.84;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = centimeter.getText().toString();
                        double d4 = Double.parseDouble(str4) /10117141.056;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        foot.removeTextChangedListener(watcher5);
                        String str5 = centimeter.getText().toString();
                        double d5 = Double.parseDouble(str5)/929.0304;
                        str5 = BigDecimal.valueOf(d5).toString();
                        foot.setText("" + str5);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str6 = centimeter.getText().toString();
                        double d6 = Double.parseDouble(str6) /6.4516;
                        str6 = BigDecimal.valueOf(d6).toString();
                        inch.setText("" + str6);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str7 = centimeter.getText().toString();
                        double d7 = Double.parseDouble(str7) / 1000000000.0*10;
                        str7 = BigDecimal.valueOf(d7).toString();
                        kilometer.setText("" + str7);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str8 = centimeter.getText().toString();
                        double d8 = Double.parseDouble(str8) / 10000;
                        str8 = BigDecimal.valueOf(d8).toString();
                        meter.setText("" + str8);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = centimeter.getText().toString();
                        double d9 = Double.parseDouble(str9) / 25899881103.36;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = centimeter.getText().toString();
                        double d10 = Double.parseDouble(str10) /0.01;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = centimeter.getText().toString();
                        double d11= Double.parseDouble(str11) / 252928.5264;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = centimeter.getText().toString();
                        double d12 = Double.parseDouble(str12) / 8361.2736;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = centimeter.getText().toString();
                        double d13 = Double.parseDouble(str13) / 93239571.9721*10000;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText5:
                    if(foot.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = foot.getText().toString();
                        double d1 = Double.parseDouble(str1) /43560;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = foot.getText().toString();
                        double d2 = Double.parseDouble(str2) /107639.1041671;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = foot.getText().toString();
                        double d3 = Double.parseDouble(str3) / 6969600;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = foot.getText().toString();
                        double d4 = Double.parseDouble(str4) /10890;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = foot.getText().toString();
                        double d5 = Double.parseDouble(str5)/0.001076391041671;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        inch.removeTextChangedListener(watcher6);
                        String str6 = foot.getText().toString();
                        double d6 = Double.parseDouble(str6) /0.006944444444445;
                        str6 = BigDecimal.valueOf(d6).toString();
                        inch.setText("" + str6);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str7 = foot.getText().toString();
                        double d7 = Double.parseDouble(str7) / 10763910.41671;
                        str7 = BigDecimal.valueOf(d7).toString();
                        kilometer.setText("" + str7);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str8 = foot.getText().toString();
                        double d8 = Double.parseDouble(str8) / 10.76391041671;
                        str8 = BigDecimal.valueOf(d8).toString();
                        meter.setText("" + str8);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = foot.getText().toString();
                        double d9 = Double.parseDouble(str9)/27878400;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = foot.getText().toString();
                        double d10 = Double.parseDouble(str10) /0.00001076391041671;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = foot.getText().toString();
                        double d11= Double.parseDouble(str11) / 272.25;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = foot.getText().toString();
                        double d12 = Double.parseDouble(str12) / 9;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = foot.getText().toString();
                        double d13 = Double.parseDouble(str13)/1003622400;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText6:
                    if(inch.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = inch.getText().toString();
                        double d1 = Double.parseDouble(str1) /6272640;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = inch.getText().toString();
                        double d2 = Double.parseDouble(str2) /15500031.00006;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = inch.getText().toString();
                        double d3 = Double.parseDouble(str3) / 1003622400;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = inch.getText().toString();
                        double d4 = Double.parseDouble(str4) /1568160;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = inch.getText().toString();
                        double d5 = Double.parseDouble(str5)/0.1550003100006;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str6 = inch.getText().toString();
                        double d6 = Double.parseDouble(str6) /144;
                        str6 = BigDecimal.valueOf(d6).toString();
                        foot.setText("" + str6);
                        foot.addTextChangedListener(watcher5);

                        kilometer.removeTextChangedListener(watcher7);
                        String str7 = inch.getText().toString();
                        double d7 = Double.parseDouble(str7) / 1550003100.006;
                        str7 = BigDecimal.valueOf(d7).toString();
                        kilometer.setText("" + str7);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str8 = inch.getText().toString();
                        double d8 = Double.parseDouble(str8) / 1550.003100006;
                        str8 = BigDecimal.valueOf(d8).toString();
                        meter.setText("" + str8);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = inch.getText().toString();
                        double d9 = Double.parseDouble(str9)/40144896.00*100;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = inch.getText().toString();
                        double d10 = Double.parseDouble(str10) /0.001550003100006;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = inch.getText().toString();
                        double d11= Double.parseDouble(str11) / 39240;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = inch.getText().toString();
                        double d12 = Double.parseDouble(str12) / 1296;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = inch.getText().toString();
                        double d13 = Double.parseDouble(str13)/1445216256.00*100;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText7:
                    if(kilometer.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = kilometer.getText().toString();
                        double d1 = Double.parseDouble(str1) /0.0040468564224;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = kilometer.getText().toString();
                        double d2 = Double.parseDouble(str2) /0.01;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = kilometer.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.647497027584;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = kilometer.getText().toString();
                        double d4 = Double.parseDouble(str4) /0.0010117141056;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = kilometer.getText().toString();
                        double d5 = Double.parseDouble(str5)*100000000.00*100;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str6 = kilometer.getText().toString();
                        double d6 = Double.parseDouble(str6) *10763910.41671;
                        str6 = BigDecimal.valueOf(d6).toString();
                        foot.setText("" + str6);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str7 = kilometer.getText().toString();
                        double d7 = Double.parseDouble(str7) * 1550003100.006;
                        str7 = BigDecimal.valueOf(d7).toString();
                        inch.setText("" + str7);
                        inch.addTextChangedListener(watcher6);

                        meter.removeTextChangedListener(watcher8);
                        String str8 = kilometer.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.000001;
                        str8 = BigDecimal.valueOf(d8).toString();
                        meter.setText("" + str8);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = kilometer.getText().toString();
                        double d9 = Double.parseDouble(str9)/2.586688110336;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = kilometer.getText().toString();
                        double d10 = Double.parseDouble(str10) *10000000000.00*100;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = kilometer.getText().toString();
                        double d11= Double.parseDouble(str11) / 0.00002529285264;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = kilometer.getText().toString();
                        double d12 = Double.parseDouble(str12) *1195990.043601;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = kilometer.getText().toString();
                        double d13 = Double.parseDouble(str13)/93.2395719271;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText8:
                    if(meter.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = meter.getText().toString();
                        double d1 = Double.parseDouble(str1) /4046.8564224;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = meter.getText().toString();
                        double d2 = Double.parseDouble(str2) /10000;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = meter.getText().toString();
                        double d3 = Double.parseDouble(str3) / 647497.027547;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = meter.getText().toString();
                        double d4 = Double.parseDouble(str4) /1011.7141056;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = meter.getText().toString();
                        double d5 = Double.parseDouble(str5)/0.0001;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str6 = meter.getText().toString();
                        double d6 = Double.parseDouble(str6) /0.09290304;
                        str6 = BigDecimal.valueOf(d6).toString();
                        foot.setText("" + str6);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str7 = meter.getText().toString();
                        double d7 = Double.parseDouble(str7) /0.00064516;
                        str7 = BigDecimal.valueOf(d7).toString();
                        inch.setText("" + str7);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str8 = meter.getText().toString();
                        double d8 = Double.parseDouble(str8) / 1000000;
                        str8 = BigDecimal.valueOf(d8).toString();
                        kilometer.setText("" + str8);
                        kilometer.addTextChangedListener(watcher7);

                        mile.removeTextChangedListener(watcher9);
                        String str9 = meter.getText().toString();
                        double d9 = Double.parseDouble(str9)/2586688.110336;
                        str9 = BigDecimal.valueOf(d9).toString();
                        mile.setText("" + str9);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = meter.getText().toString();
                        double d10 = Double.parseDouble(str10) /0.000001;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = meter.getText().toString();
                        double d11= Double.parseDouble(str11) / 25.29285264;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = meter.getText().toString();
                        double d12 = Double.parseDouble(str12) /0.83612736;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = meter.getText().toString();
                        double d13 = Double.parseDouble(str13)/93239571.9271;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText9:
                    if(mile.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = mile.getText().toString();
                        double d1 = Double.parseDouble(str1) /0.0015625;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = mile.getText().toString();
                        double d2 = Double.parseDouble(str2) /0.003861021585424;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = mile.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.25;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = mile.getText().toString();
                        double d4 = Double.parseDouble(str4) /0.0003390625;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = mile.getText().toString();
                        double d5 = Double.parseDouble(str5)*25899881103.36;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str6 = mile.getText().toString();
                        double d6 = Double.parseDouble(str6) *27878400;
                        str6 = BigDecimal.valueOf(d6).toString();
                        foot.setText("" + str6);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str7 = mile.getText().toString();
                        double d7 = Double.parseDouble(str7) *40144896.00*100;
                        str7 = BigDecimal.valueOf(d7).toString();
                        inch.setText("" + str7);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str8 = mile.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.3816021585425;
                        str8 = BigDecimal.valueOf(d8).toString();
                        kilometer.setText("" + str8);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str9 = mile.getText().toString();
                        double d9 = Double.parseDouble(str9)*2586688.110336;
                        str9 = BigDecimal.valueOf(d9).toString();
                        meter.setText("" + str9);
                        meter.addTextChangedListener(watcher8);

                        milimeter.removeTextChangedListener(watcher10);
                        String str10 = mile.getText().toString();
                        double d10 = Double.parseDouble(str10) *2586688.110336*1000000;
                        str10 = BigDecimal.valueOf(d10).toString();
                        milimeter.setText("" + str10);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = mile.getText().toString();
                        double d11= Double.parseDouble(str11) / 0.000009765625;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = mile.getText().toString();
                        double d12 = Double.parseDouble(str12) *3097600;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = mile.getText().toString();
                        double d13 = Double.parseDouble(str13)/36;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText10:
                    if(milimeter.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = milimeter.getText().toString();
                        double d1 = Double.parseDouble(str1) /4046856422.4;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = milimeter.getText().toString();
                        double d2 = Double.parseDouble(str2) /100000000.00*100;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = milimeter.getText().toString();
                        double d3 = Double.parseDouble(str3) / 6474970275.84*100;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = milimeter.getText().toString();
                        double d4 = Double.parseDouble(str4) /1011714105.6;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = milimeter.getText().toString();
                        double d5 = Double.parseDouble(str5)/100;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str6 = milimeter.getText().toString();
                        double d6 = Double.parseDouble(str6) /92903.04;
                        str6 = BigDecimal.valueOf(d6).toString();
                        foot.setText("" + str6);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str7 = milimeter.getText().toString();
                        double d7 = Double.parseDouble(str7) /645.16;
                        str7 = BigDecimal.valueOf(d7).toString();
                        inch.setText("" + str7);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str8 = milimeter.getText().toString();
                        double d8 = Double.parseDouble(str8) / 10000000000.00*100;
                        str8 = BigDecimal.valueOf(d8).toString();
                        kilometer.setText("" + str8);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str9 = milimeter.getText().toString();
                        double d9 = Double.parseDouble(str9)/1000000;
                        str9 = BigDecimal.valueOf(d9).toString();
                        meter.setText("" + str9);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str10 = milimeter.getText().toString();
                        double d10 = Double.parseDouble(str10) /2586688.110336*1000000;
                        str10 = BigDecimal.valueOf(d10).toString();
                        mile.setText("" + str10);
                        mile.addTextChangedListener(watcher9);

                        rod.removeTextChangedListener(watcher11);
                        String str11 = milimeter.getText().toString();
                        double d11= Double.parseDouble(str11) / 25292852.64;
                        str11 = BigDecimal.valueOf(d11).toString();
                        rod.setText("" + str11);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = milimeter.getText().toString();
                        double d12 = Double.parseDouble(str12) /836127.36;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = milimeter.getText().toString();
                        double d13 = Double.parseDouble(str13)/9323951719721.00*100;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText11:
                    if(rod.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = rod.getText().toString();
                        double d1 = Double.parseDouble(str1) /160;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = rod.getText().toString();
                        double d2 = Double.parseDouble(str2) /395.3686103475;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = rod.getText().toString();
                        double d3 = Double.parseDouble(str3) / 25600;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = rod.getText().toString();
                        double d4 = Double.parseDouble(str4) /40;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = rod.getText().toString();
                        double d5 = Double.parseDouble(str5)/0.000003953686103475;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str6 = rod.getText().toString();
                        double d6 = Double.parseDouble(str6) /0.003673094582185;
                        str6 = BigDecimal.valueOf(d6).toString();
                        foot.setText("" + str6);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str7 = rod.getText().toString();
                        double d7 = Double.parseDouble(str7) /0.00002550760126581;
                        str7 = BigDecimal.valueOf(d7).toString();
                        inch.setText("" + str7);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str8 = rod.getText().toString();
                        double d8 = Double.parseDouble(str8) / 39536.86103475;
                        str8 = BigDecimal.valueOf(d8).toString();
                        kilometer.setText("" + str8);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str9 = rod.getText().toString();
                        double d9 = Double.parseDouble(str9)/0.03953686103475;
                        str9 = BigDecimal.valueOf(d9).toString();
                        meter.setText("" + str9);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str10 = rod.getText().toString();
                        double d10 = Double.parseDouble(str10) /102400;
                        str10 = BigDecimal.valueOf(d10).toString();
                        mile.setText("" + str10);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str11 = rod.getText().toString();
                        double d11= Double.parseDouble(str11) * 25292852.64;
                        str11 = BigDecimal.valueOf(d11).toString();
                        milimeter.setText("" + str11);
                        milimeter.addTextChangedListener(watcher10);

                        yard.removeTextChangedListener(watcher12);
                        String str12 = rod.getText().toString();
                        double d12 = Double.parseDouble(str12) /0.03305785123967;
                        str12 = BigDecimal.valueOf(d12).toString();
                        yard.setText("" + str12);
                        yard.addTextChangedListener(watcher12);

                        township.removeTextChangedListener(watcher13);
                        String str13 = rod.getText().toString();
                        double d13 = Double.parseDouble(str13)/3686400;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText12:
                    if(yard.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = yard.getText().toString();
                        double d1 = Double.parseDouble(str1) /4840;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = yard.getText().toString();
                        double d2 = Double.parseDouble(str2) /11959.90043601;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = yard.getText().toString();
                        double d3 = Double.parseDouble(str3) /774400;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = yard.getText().toString();
                        double d4 = Double.parseDouble(str4) /1210;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = yard.getText().toString();
                        double d5 = Double.parseDouble(str5)/0.0001195990043601;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str6 = yard.getText().toString();
                        double d6 = Double.parseDouble(str6) /0.1111111111111;
                        str6 = BigDecimal.valueOf(d6).toString();
                        foot.setText("" + str6);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str7 = yard.getText().toString();
                        double d7 = Double.parseDouble(str7) /0.0007716049382716;
                        str7 = BigDecimal.valueOf(d7).toString();
                        inch.setText("" + str7);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str8 = yard.getText().toString();
                        double d8 = Double.parseDouble(str8) / 1195990.043601;
                        str8 = BigDecimal.valueOf(d8).toString();
                        kilometer.setText("" + str8);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str9 = yard.getText().toString();
                        double d9 = Double.parseDouble(str9)/1.195990043601;
                        str9 = BigDecimal.valueOf(d9).toString();
                        meter.setText("" + str9);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str10 = yard.getText().toString();
                        double d10 = Double.parseDouble(str10) /3097600;
                        str10 = BigDecimal.valueOf(d10).toString();
                        mile.setText("" + str10);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str11 = yard.getText().toString();
                        double d11= Double.parseDouble(str11) /0.000001195990043601;
                        str11 = BigDecimal.valueOf(d11).toString();
                        milimeter.setText("" + str11);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str12 = yard.getText().toString();
                        double d12 = Double.parseDouble(str12) /30.25;
                        str12 = BigDecimal.valueOf(d12).toString();
                        rod.setText("" + str12);
                        rod.addTextChangedListener(watcher11);

                        township.removeTextChangedListener(watcher13);
                        String str13 = yard.getText().toString();
                        double d13 = Double.parseDouble(str13)/111513600;
                        str13 = BigDecimal.valueOf(d13).toString();
                        township.setText("" + str13);
                        township.addTextChangedListener(watcher13);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;
                case R.id.editText13:
                    if(township.length()!=0)
                    {
                        acre.removeTextChangedListener(watcher0);
                        String str1 = township.getText().toString();
                        double d1 = Double.parseDouble(str1) /0.00004340277777778;
                        str1 = BigDecimal.valueOf(d1).toString();
                        acre.setText("" + str1);
                        acre.addTextChangedListener(watcher0);

                        hectaer.removeTextChangedListener(watcher1);
                        String str2 = township.getText().toString();
                        double d2 = Double.parseDouble(str2) /0.00010725059959551;
                        str2 = BigDecimal.valueOf(d2).toString();
                        hectaer.setText("" + str2);
                        hectaer.addTextChangedListener(watcher1);

                        homestead.removeTextChangedListener(watcher2);
                        String str3 = township.getText().toString();
                        double d3 = Double.parseDouble(str3) /0.006944444444444;
                        str3 = BigDecimal.valueOf(d3).toString();
                        homestead.setText("" + str3);
                        homestead.addTextChangedListener(watcher2);

                        rood.removeTextChangedListener(watcher3);
                        String str4 = township.getText().toString();
                        double d4 = Double.parseDouble(str4) /0.00001085069444444;
                        str4 = BigDecimal.valueOf(d4).toString();
                        rood.setText("" + str4);
                        rood.addTextChangedListener(watcher3);

                        centimeter.removeTextChangedListener(watcher4);
                        String str5 = township.getText().toString();
                        double d5 = Double.parseDouble(str5)*9323957197.21*100;
                        str5 = BigDecimal.valueOf(d5).toString();
                        centimeter.setText("" + str5);
                        centimeter.addTextChangedListener(watcher4);

                        foot.removeTextChangedListener(watcher5);
                        String str6 = township.getText().toString();
                        double d6 = Double.parseDouble(str6)*1003622400;
                        str6 = BigDecimal.valueOf(d6).toString();
                        foot.setText("" + str6);
                        foot.addTextChangedListener(watcher5);

                        inch.removeTextChangedListener(watcher6);
                        String str7 = township.getText().toString();
                        double d7 = Double.parseDouble(str7) *1445216256.00*100;
                        str7 = BigDecimal.valueOf(d7).toString();
                        inch.setText("" + str7);
                        inch.addTextChangedListener(watcher6);

                        kilometer.removeTextChangedListener(watcher7);
                        String str8 = township.getText().toString();
                        double d8 = Double.parseDouble(str8) /0.01072505995951;
                        str8 = BigDecimal.valueOf(d8).toString();
                        kilometer.setText("" + str8);
                        kilometer.addTextChangedListener(watcher7);

                        meter.removeTextChangedListener(watcher8);
                        String str9 = township.getText().toString();
                        double d9 = Double.parseDouble(str9)*93239571.9721;
                        str9 = BigDecimal.valueOf(d9).toString();
                        meter.setText("" + str9);
                        meter.addTextChangedListener(watcher8);

                        mile.removeTextChangedListener(watcher9);
                        String str10 = township.getText().toString();
                        double d10 = Double.parseDouble(str10) /0.02777777777778;
                        str10 = BigDecimal.valueOf(d10).toString();
                        mile.setText("" + str10);
                        mile.addTextChangedListener(watcher9);

                        milimeter.removeTextChangedListener(watcher10);
                        String str11 = township.getText().toString();
                        double d11= Double.parseDouble(str11) *932395719721.00*100;
                        str11 = BigDecimal.valueOf(d11).toString();
                        milimeter.setText("" + str11);
                        milimeter.addTextChangedListener(watcher10);

                        rod.removeTextChangedListener(watcher11);
                        String str12 = township.getText().toString();
                        double d12 = Double.parseDouble(str12) *3686400;
                        str12 = BigDecimal.valueOf(d12).toString();
                        rod.setText("" + str12);
                        rod.addTextChangedListener(watcher11);

                        yard.removeTextChangedListener(watcher12);
                        String str13 = township.getText().toString();
                        double d13 = Double.parseDouble(str13)*111513600;
                        str13 = BigDecimal.valueOf(d13).toString();
                        yard.setText("" + str13);
                        yard.addTextChangedListener(watcher12);
                    }
                    else
                    {
                        acre.setText("0");
                        hectaer.setText("0");
                        homestead.setText("0");
                        rood.setText("0");
                        centimeter.setText("0");
                        foot.setText("0");
                        inch.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        milimeter.setText("0");
                        rod.setText("0");
                        yard.setText("0");
                        township.setText("0");
                    }
                    break;

            }
            // TODO Auto-generated method stub
        }}

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.area, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.currency) {
            startActivity(new Intent(this,Currency.class));
            this.finish();
        } else if (id == R.id.area) {
            startActivity(new Intent(this,Area.class));
            this.finish();
        }
        else if (id == R.id.angle) {
            startActivity(new Intent(this, Angle.class));
            this.finish();
        }
        else if (id == R.id.storage) {
            startActivity(new Intent(this, Data_Storage.class));
            this.finish();
        }
        else if (id == R.id.astronomical) {
            startActivity(new Intent(this, Astronomical.class));
            this.finish();
        }
        else if (id == R.id.capture) {
            Intent i=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            startActivity(i);
        }
        else if (id == R.id.gallary) {
            Intent i=new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            startActivity(i);
        }
        else if (id == R.id.calulater) {
            startActivity(new Intent(this, Calculate.class));
            this.finish();
        }
        else if (id == R.id.flash) {
            startActivity(new Intent(this, Flash.class));
            this.finish();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
