package com.example.puneetgoyal.converter;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

import java.math.BigDecimal;

public class Astronomical extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    EditText parse, ast, kilometer,meter, mile, year,day, week, hour,min,second;
    private CustomWatcher watcher0,watcher1,watcher2,watcher3,watcher4,watcher5,watcher6,watcher7,watcher8,watcher9,watcher10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_astronomical);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP)
        {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.colorAsDark));
        }
        parse = (EditText) findViewById(R.id.editText0);
        ast = (EditText) findViewById(R.id.editText1);
        kilometer = (EditText) findViewById(R.id.editText2);
        meter = (EditText) findViewById(R.id.editText3);
        mile = (EditText) findViewById(R.id.editText4);
        year = (EditText) findViewById(R.id.editText5);
        day = (EditText) findViewById(R.id.editText6);
        week = (EditText) findViewById(R.id.editText7);
        hour = (EditText) findViewById(R.id.editText8);
        min = (EditText) findViewById(R.id.editText9);
        second = (EditText) findViewById(R.id.editText10);
        watcher0=new CustomWatcher(parse);
        watcher1=new CustomWatcher(ast);
        watcher2=new CustomWatcher(kilometer);
        watcher3=new CustomWatcher(meter);
        watcher4=new CustomWatcher(mile);
        watcher5=new CustomWatcher(year);
        watcher6=new CustomWatcher(day);
        watcher7=new CustomWatcher(week);
        watcher8=new CustomWatcher(hour);
        watcher9=new CustomWatcher(min);
        watcher10=new CustomWatcher(second);

        parse.addTextChangedListener(watcher0);
        ast.addTextChangedListener(watcher1);
        kilometer.addTextChangedListener(watcher2);
        meter.addTextChangedListener(watcher3);
        mile.addTextChangedListener(watcher4);
        year.addTextChangedListener(watcher5);
        day.addTextChangedListener(watcher6);
        week.addTextChangedListener(watcher7);
        hour.addTextChangedListener(watcher8);
        min.addTextChangedListener(watcher9);
        second.addTextChangedListener(watcher10);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setBackgroundTintList(getResources().getColorStateList(R.color.colorAs));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }
    public	class CustomWatcher implements TextWatcher {
        private View view;
        public CustomWatcher(View view) {
            this.view = view;
        }

        @Override
        public void afterTextChanged(Editable arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                  int arg3) {

            switch (view.getId()) {
                case R.id.editText0:
                    if (parse.length() != 0) {
                        ast.removeTextChangedListener(watcher1);
                        String str1 = parse.getText().toString();
                        double d1 = Double.parseDouble(str1) / 0.000004848136776084;
                        str1 = BigDecimal.valueOf(d1).toString();
                        ast.setText("" + str1);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str2 = parse.getText().toString();
                        double d2 = Double.parseDouble(str2) *308567760295.00*100;
                        str2 = BigDecimal.valueOf(d2).toString();
                        kilometer.setText("" + str2);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str3 = parse.getText().toString();
                        double d3 = Double.parseDouble(str3) / 30856776029500.00*100;
                        str3 = BigDecimal.valueOf(d3).toString();
                        meter.setText("" + str3);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str4 = parse.getText().toString();
                        double d4 = Double.parseDouble(str4) /191677946032.20*100;
                        str4 = BigDecimal.valueOf(d4).toString();
                        mile.setText("" + str4);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str5 = parse.getText().toString();
                        double d5 = Double.parseDouble(str5) /0.3065950959227;
                        str5 = BigDecimal.valueOf(d5).toString();
                        year.setText("" + str5);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str6 = parse.getText().toString();
                        double d6 = Double.parseDouble(str6) /0.0008394288614352;
                        str6 = BigDecimal.valueOf(d6).toString();
                        day.setText("" + str6);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str7 = parse.getText().toString();
                        double d7 = Double.parseDouble(str7) / 0.005876002030046;
                        str7 = BigDecimal.valueOf(d7).toString();
                        week.setText("" + str7);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str8 = parse.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.0000349762025598;
                        str8 = BigDecimal.valueOf(d8).toString();
                        hour.setText("" + str8);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str9 = parse.getText().toString();
                        double d9 = Double.parseDouble(str9) *1715452.096248;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = parse.getText().toString();
                        double d10 = Double.parseDouble(str10) *102927125.7749;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);


                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText1:
                    if (ast.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = ast.getText().toString();
                        double d1 = Double.parseDouble(str1) * 0.000004848136776084;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        kilometer.removeTextChangedListener(watcher2);
                        String str2 = ast.getText().toString();
                        double d2 = Double.parseDouble(str2) * 149597870.66;
                        str2 = BigDecimal.valueOf(d2).toString();
                        kilometer.setText("" + str2);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str3 = ast.getText().toString();
                        double d3 = Double.parseDouble(str3) * 14959787066.0*10;
                        str3 = BigDecimal.valueOf(d3).toString();
                        meter.setText("" + str3);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str4 = ast.getText().toString();
                        double d4 = Double.parseDouble(str4) *92928089.93228;
                        str4 = BigDecimal.valueOf(d4).toString();
                        mile.setText("" + str4);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str5 = ast.getText().toString();
                        double d5 = Double.parseDouble(str5) * 0.00001581283210514;
                        str5 = BigDecimal.valueOf(d5).toString();
                        year.setText("" + str5);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str6 = ast.getText().toString();
                        double d6 = Double.parseDouble(str6) * 0.00577551899016;
                        str6 = BigDecimal.valueOf(d6).toString();
                        day.setText("" + str6);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str7 = ast.getText().toString();
                        double d7 = Double.parseDouble(str7) * 0.0008250740471658;
                        str7 = BigDecimal.valueOf(d7).toString();
                        week.setText("" + str7);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str8 = ast.getText().toString();
                        double d8 = Double.parseDouble(str8) * 0.1386124399239;
                        str8 = BigDecimal.valueOf(d8).toString();
                        hour.setText("" + str8);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str9 = ast.getText().toString();
                        double d9 = Double.parseDouble(str9) * 8.316746395431;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = ast.getText().toString();
                        double d10 = Double.parseDouble(str10) * 499.004837259;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText2:
                    if (kilometer.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = kilometer.getText().toString();
                        double d1 = Double.parseDouble(str1) /308567760295.00*100;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = kilometer.getText().toString();
                        double d2 = Double.parseDouble(str2) / 149597870.66;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        meter.removeTextChangedListener(watcher3);
                        String str3 = kilometer.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.001;
                        str3 = BigDecimal.valueOf(d3).toString();
                        meter.setText("" + str3);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str4 = kilometer.getText().toString();
                        double d4 = Double.parseDouble(str4) /1.609824013052;
                        str4 = BigDecimal.valueOf(d4).toString();
                        mile.setText("" + str4);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str5 = kilometer.getText().toString();
                        double d5 = Double.parseDouble(str5) /94605362066.30*100;
                        str5 = BigDecimal.valueOf(d5).toString();
                        year.setText("" + str5);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str6 = kilometer.getText().toString();
                        double d6 = Double.parseDouble(str6) /259020683.70*100;
                        str6 = BigDecimal.valueOf(d6).toString();
                        day.setText("" + str6);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str7 = kilometer.getText().toString();
                        double d7 = Double.parseDouble(str7) /1813144785.90*100;
                        str7 = BigDecimal.valueOf(d7).toString();
                        week.setText("" + str7);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str8 = kilometer.getText().toString();
                        double d8 = Double.parseDouble(str8) / 1079252848.75;
                        str8 = BigDecimal.valueOf(d8).toString();
                        hour.setText("" + str8);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str9 = kilometer.getText().toString();
                        double d9 = Double.parseDouble(str9) / 17987547.47917;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = kilometer.getText().toString();
                        double d10 = Double.parseDouble(str10) / 299792.4579861;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText3:
                    if (meter.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = meter.getText().toString();
                        double d1 = Double.parseDouble(str1) / 308567760295.00000*100000;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = meter.getText().toString();
                        double d2 = Double.parseDouble(str2) / 1495978706.60*100;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str3 = meter.getText().toString();
                        double d3 = Double.parseDouble(str3) / 1000;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kilometer.setText("" + str3);
                        kilometer.addTextChangedListener(watcher2);

                        mile.removeTextChangedListener(watcher4);
                        String str4 = meter.getText().toString();
                        double d4 = Double.parseDouble(str4) /1609.824013052;
                        str4 = BigDecimal.valueOf(d4).toString();
                        mile.setText("" + str4);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str5 = meter.getText().toString();
                        double d5 = Double.parseDouble(str5) / 946053620663.0000*10000;
                        str5 = BigDecimal.valueOf(d5).toString();
                        year.setText("" + str5);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str6 = meter.getText().toString();
                        double d6 = Double.parseDouble(str6) /2590206837.0000*10000;
                        str6 = BigDecimal.valueOf(d6).toString();
                        day.setText("" + str6);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str7 = meter.getText().toString();
                        double d7 = Double.parseDouble(str7) / 18131447859.0000*10000;
                        str7 = BigDecimal.valueOf(d7).toString();
                        week.setText("" + str7);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str8 = meter.getText().toString();
                        double d8 = Double.parseDouble(str8) /1079252848.750*1000;
                        str8 = BigDecimal.valueOf(d8).toString();
                        hour.setText("" + str8);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str9 = meter.getText().toString();
                        double d9 = Double.parseDouble(str9) / 17987547479.17;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = meter.getText().toString();
                        double d10 = Double.parseDouble(str10) /299792457.9861;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText4:
                    if (mile.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = mile.getText().toString();
                        double d1 = Double.parseDouble(str1) / 19167794603.220*1000;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = mile.getText().toString();
                        double d2 = Double.parseDouble(str2) / 92928089.93228;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str3 = mile.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.6211859134244;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kilometer.setText("" + str3);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str4 = mile.getText().toString();
                        double d4 = Double.parseDouble(str4) / 0.0006211859134244;
                        str4 = BigDecimal.valueOf(d4).toString();
                        meter.setText("" + str4);
                        meter.addTextChangedListener(watcher3);

                        year.removeTextChangedListener(watcher5);
                        String str5 = mile.getText().toString();
                        double d5 = Double.parseDouble(str5) /5876751825.000*1000;
                        str5 = BigDecimal.valueOf(d5).toString();
                        year.setText("" + str5);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str6 = mile.getText().toString();
                        double d6 = Double.parseDouble(str6) / 16090000.000*1000;
                        str6 = BigDecimal.valueOf(d6).toString();
                        day.setText("" + str6);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str7 = mile.getText().toString();
                        double d7 = Double.parseDouble(str7) / 11263000000.0 * 10;
                        str7 = BigDecimal.valueOf(d7).toString();
                        week.setText("" + str7);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str8 = mile.getText().toString();
                        double d8 = Double.parseDouble(str8) / 670416666.6667;
                        str8 = BigDecimal.valueOf(d8).toString();
                        hour.setText("" + str8);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str9 = mile.getText().toString();
                        double d9 = Double.parseDouble(str9) / 11173611.11111;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = mile.getText().toString();
                        double d10 = Double.parseDouble(str10) / 186226.8518519;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText5:
                    if (year.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = year.getText().toString();
                        double d1 = Double.parseDouble(str1) / 3.261630773938;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = year.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.00001581283210514;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str3 = year.getText().toString();
                        double d3 = Double.parseDouble(str3) *94605362066.30*100;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kilometer.setText("" + str3);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str4 = year.getText().toString();
                        double d4 = Double.parseDouble(str4) * 946053620663.0000*1000;
                        str4 = BigDecimal.valueOf(d4).toString();
                        meter.setText("" + str4);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str5 = year.getText().toString();
                        double d5 = Double.parseDouble(str5) *5876751825.000*1000;
                        str5 = BigDecimal.valueOf(d5).toString();
                        mile.setText("" + str5);
                        mile.addTextChangedListener(watcher4);

                        day.removeTextChangedListener(watcher6);
                        String str6 = year.getText().toString();
                        double d6 = Double.parseDouble(str6) / 0.002737907006989;
                        str6 = BigDecimal.valueOf(d6).toString();
                        day.setText("" + str6);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str7 = year.getText().toString();
                        double d7 = Double.parseDouble(str7) / 0.01916534904892;
                        str7 = BigDecimal.valueOf(d7).toString();
                        week.setText("" + str7);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str8 = year.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.0001140794586245;
                        str8 = BigDecimal.valueOf(d8).toString();
                        hour.setText("" + str8);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str9 = year.getText().toString();
                        double d9 = Double.parseDouble(str9) / 0.000001901324310409;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = year.getText().toString();
                        double d10 = Double.parseDouble(str10) *31556952;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText6:
                    if (day.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = day.getText().toString();
                        double d1 = Double.parseDouble(str1) / 1191.28617795;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = day.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.00577551833016;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str3 = day.getText().toString();
                        double d3 = Double.parseDouble(str3) *2590206837.0*10;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kilometer.setText("" + str3);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str4 = day.getText().toString();
                        double d4 = Double.parseDouble(str4) *2590206837.0000*1000;
                        str4 = BigDecimal.valueOf(d4).toString();
                        meter.setText("" + str4);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str5 = day.getText().toString();
                        double d5 = Double.parseDouble(str5) * 160900000.00*100;
                        str5 = BigDecimal.valueOf(d5).toString();
                        mile.setText("" + str5);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str6 = day.getText().toString();
                        double d6 = Double.parseDouble(str6) /365.2425 ;
                        str6 = BigDecimal.valueOf(d6).toString();
                        year.setText("" + str6);
                        year.addTextChangedListener(watcher5);

                        week.removeTextChangedListener(watcher7);
                        String str7 = day.getText().toString();
                        double d7 = Double.parseDouble(str7) / 7;
                        str7 = BigDecimal.valueOf(d7).toString();
                        week.setText("" + str7);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str8 = day.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.04166666666667;
                        str8 = BigDecimal.valueOf(d8).toString();
                        hour.setText("" + str8);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str9 = day.getText().toString();
                        double d9 = Double.parseDouble(str9) / 0.0006944444444444;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = day.getText().toString();
                        double d10 = Double.parseDouble(str10) / 0.00001157407407407;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText7:
                    if (week.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = week.getText().toString();
                        double d1 = Double.parseDouble(str1) / 170.1837397071;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = week.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.0008250740471658;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str3 = week.getText().toString();
                        double d3 = Double.parseDouble(str3) *18131447859.0*10;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kilometer.setText("" + str3);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str4 = week.getText().toString();
                        double d4 = Double.parseDouble(str4) *18131447859.0000*10000;
                        str4 = BigDecimal.valueOf(d4).toString();
                        meter.setText("" + str4);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str5 = week.getText().toString();
                        double d5 = Double.parseDouble(str5) *1126300000.00*00;
                        str5 = BigDecimal.valueOf(d5).toString();
                        mile.setText("" + str5);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str6 = week.getText().toString();
                        double d6 = Double.parseDouble(str6) /52.1775;
                        str6 = BigDecimal.valueOf(d6).toString();
                        year.setText("" + str6);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str7 = week.getText().toString();
                        double d7 = Double.parseDouble(str7) /0.1428571428571;
                        str7 = BigDecimal.valueOf(d7).toString();
                        day.setText("" + str7);
                        day.addTextChangedListener(watcher6);

                        hour.removeTextChangedListener(watcher8);
                        String str8 = week.getText().toString();
                        double d8 = Double.parseDouble(str8) / 0.005952380952381;
                        str8 = BigDecimal.valueOf(d8).toString();
                        hour.setText("" + str8);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str9 = week.getText().toString();
                        double d9 = Double.parseDouble(str9) / 0.00009920634920635;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = week.getText().toString();
                        double d10 = Double.parseDouble(str10) /0.000001653439153439;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText8:
                    if (hour.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = hour.getText().toString();
                        double d1 = Double.parseDouble(str1) / 28590.8682708;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = hour.getText().toString();
                        double d2 = Double.parseDouble(str2) / 0.1386124399239;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str3 = hour.getText().toString();
                        double d3 = Double.parseDouble(str3) *10792452848.75;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kilometer.setText("" + str3);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str4 = hour.getText().toString();
                        double d4 = Double.parseDouble(str4) *10792452848.750*1000;
                        str4 = BigDecimal.valueOf(d4).toString();
                        meter.setText("" + str4);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str5 = hour.getText().toString();
                        double d5 = Double.parseDouble(str5) *6704116666.6667;
                        str5 = BigDecimal.valueOf(d5).toString();
                        mile.setText("" + str5);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str6 = hour.getText().toString();
                        double d6 = Double.parseDouble(str6) / 8765.82;
                        str6 = BigDecimal.valueOf(d6).toString();
                        year.setText("" + str6);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str7 = hour.getText().toString();
                        double d7 = Double.parseDouble(str7) / 24;
                        str7 = BigDecimal.valueOf(d7).toString();
                        day.setText("" + str7);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str8 = hour.getText().toString();
                        double d8 = Double.parseDouble(str8) / 168;
                        str8 = BigDecimal.valueOf(d8).toString();
                        week.setText("" + str8);
                        week.addTextChangedListener(watcher7);

                        min.removeTextChangedListener(watcher9);
                        String str9 = hour.getText().toString();
                        double d9 = Double.parseDouble(str9) / 0.01666666666667;
                        str9 = BigDecimal.valueOf(d9).toString();
                        min.setText("" + str9);
                        min.addTextChangedListener(watcher9);

                        second.removeTextChangedListener(watcher10);
                        String str10 = hour.getText().toString();
                        double d10 = Double.parseDouble(str10) / 0.0002777777777778;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText9:
                    if (min.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = min.getText().toString();
                        double d1 = Double.parseDouble(str1) / 1715452.096248;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = min.getText().toString();
                        double d2 = Double.parseDouble(str2) / 8.316746395431;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str3 = min.getText().toString();
                        double d3 = Double.parseDouble(str3) * 17987547.47917;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kilometer.setText("" + str3);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str4 = min.getText().toString();
                        double d4 = Double.parseDouble(str4) * 17987547479.17;
                        str4 = BigDecimal.valueOf(d4).toString();
                        meter.setText("" + str4);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str5 = min.getText().toString();
                        double d5 = Double.parseDouble(str5) * 11173611.11111;
                        str5 = BigDecimal.valueOf(d5).toString();
                        mile.setText("" + str5);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str6 = min.getText().toString();
                        double d6 = Double.parseDouble(str6)/525949.2;
                        str6 = BigDecimal.valueOf(d6).toString();
                        year.setText("" + str6);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str7 = min.getText().toString();
                        double d7 = Double.parseDouble(str7) /1440;
                        str7 = BigDecimal.valueOf(d7).toString();
                        day.setText("" + str7);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str8 = min.getText().toString();
                        double d8 = Double.parseDouble(str8) / 10080;
                        str8 = BigDecimal.valueOf(d8).toString();
                        week.setText("" + str8);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str9 = min.getText().toString();
                        double d9 = Double.parseDouble(str9) /60;
                        str9 = BigDecimal.valueOf(d9).toString();
                        hour.setText("" + str9);
                        hour.addTextChangedListener(watcher8);

                        second.removeTextChangedListener(watcher10);
                        String str10 = min.getText().toString();
                        double d10 = Double.parseDouble(str10)/0.01666666666667;
                        str10 = BigDecimal.valueOf(d10).toString();
                        second.setText("" + str10);
                        second.addTextChangedListener(watcher10);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
                case R.id.editText10:
                    if (second.length() != 0) {
                        parse.removeTextChangedListener(watcher0);
                        String str1 = second.getText().toString();
                        double d1 = Double.parseDouble(str1) / 102927125.7749;
                        str1 = BigDecimal.valueOf(d1).toString();
                        parse.setText("" + str1);
                        parse.addTextChangedListener(watcher0);

                        ast.removeTextChangedListener(watcher1);
                        String str2 = second.getText().toString();
                        double d2 = Double.parseDouble(str2) / 499.0047837259;
                        str2 = BigDecimal.valueOf(d2).toString();
                        ast.setText("" + str2);
                        ast.addTextChangedListener(watcher1);

                        kilometer.removeTextChangedListener(watcher2);
                        String str3 = second.getText().toString();
                        double d3 = Double.parseDouble(str3) / 0.000003335640952136;
                        str3 = BigDecimal.valueOf(d3).toString();
                        kilometer.setText("" + str3);
                        kilometer.addTextChangedListener(watcher2);

                        meter.removeTextChangedListener(watcher3);
                        String str4 = second.getText().toString();
                        double d4 = Double.parseDouble(str4) *299792457.9861;
                        str4 = BigDecimal.valueOf(d4).toString();
                        meter.setText("" + str4);
                        meter.addTextChangedListener(watcher3);

                        mile.removeTextChangedListener(watcher4);
                        String str5 = second.getText().toString();
                        double d5 = Double.parseDouble(str5) *186226.8518519;
                        str5 = BigDecimal.valueOf(d5).toString();
                        mile.setText("" + str5);
                        mile.addTextChangedListener(watcher4);

                        year.removeTextChangedListener(watcher5);
                        String str6 = second.getText().toString();
                        double d6 = Double.parseDouble(str6) / 31556952;
                        str6 = BigDecimal.valueOf(d6).toString();
                        year.setText("" + str6);
                        year.addTextChangedListener(watcher5);

                        day.removeTextChangedListener(watcher6);
                        String str7 = second.getText().toString();
                        double d7 = Double.parseDouble(str7) / 86400;
                        str7 = BigDecimal.valueOf(d7).toString();
                        day.setText("" + str7);
                        day.addTextChangedListener(watcher6);

                        week.removeTextChangedListener(watcher7);
                        String str8 = second.getText().toString();
                        double d8 = Double.parseDouble(str8) /  604800;
                        str8 = BigDecimal.valueOf(d8).toString();
                        week.setText("" + str8);
                        week.addTextChangedListener(watcher7);

                        hour.removeTextChangedListener(watcher8);
                        String str9 = second.getText().toString();
                        double d9 = Double.parseDouble(str9) / 3600;
                        str9 = BigDecimal.valueOf(d9).toString();
                        hour.setText("" + str9);
                        hour.addTextChangedListener(watcher8);

                        min.removeTextChangedListener(watcher9);
                        String str10 = second.getText().toString();
                        double d10 = Double.parseDouble(str10) / 60;
                        str10 = BigDecimal.valueOf(d10).toString();
                        min.setText("" + str10);
                        min.addTextChangedListener(watcher9);

                    } else {
                        parse.setText("0");
                        ast.setText("0");
                        kilometer.setText("0");
                        meter.setText("0");
                        mile.setText("0");
                        year.setText("0");
                        day.setText("0");
                        week.setText("0");
                        hour.setText("0");
                        min.setText("0");
                        second.setTag("0");
                    }
                    break;
            }
        }}

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.astronomical, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.currency) {
            startActivity(new Intent(this,Currency.class));
            this.finish();
        } else if (id == R.id.area) {
            startActivity(new Intent(this,Area.class));
            this.finish();
        }
        else if (id == R.id.angle) {
            startActivity(new Intent(this, Angle.class));
            this.finish();
        }
        else if (id == R.id.storage) {
            startActivity(new Intent(this, Data_Storage.class));
            this.finish();
        }
        else if (id == R.id.astronomical) {
            startActivity(new Intent(this, Astronomical.class));
            this.finish();
        }
        else if (id == R.id.capture) {
            Intent i=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            startActivity(i);
        }
        else if (id == R.id.gallary) {
            Intent i=new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            startActivity(i);
        }
        else if (id == R.id.calulater) {
            startActivity(new Intent(this, Calculate.class));
            this.finish();
        }
        else if (id == R.id.flash) {
            startActivity(new Intent(this, Flash.class));
            this.finish();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
